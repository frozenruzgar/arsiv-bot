from __future__ import annotations

import threading
import time
import webbrowser
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ARCHIVE_ROOT = ROOT / "archive_bot"
if str(ARCHIVE_ROOT) not in sys.path:
    sys.path.insert(0, str(ARCHIVE_ROOT))

from web_server import main  # noqa: E402


def open_panel() -> None:
    time.sleep(1.5)
    webbrowser.open("http://127.0.0.1:5090")


if __name__ == "__main__":
    threading.Thread(target=open_panel, daemon=True).start()
    main()
