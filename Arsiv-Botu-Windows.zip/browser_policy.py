from __future__ import annotations

import os
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


SUPPORTED_BROWSER_IDS = ("chrome", "edge", "brave", "opera")
BROWSER_NAMES = {
    "chrome": "Google Chrome",
    "edge": "Microsoft Edge",
    "brave": "Brave",
    "opera": "Opera",
}


@dataclass(frozen=True)
class BrowserChoice:
    browser_id: str
    name: str
    executable: Path
    version: str = ""

    @property
    def major(self) -> int | None:
        try:
            return int(self.version.split(".", 1)[0])
        except (TypeError, ValueError):
            return None

    def public_payload(self) -> dict[str, object]:
        payload = asdict(self)
        payload["executable"] = str(self.executable)
        payload["major"] = self.major
        return payload


def clean_browser_ids(value: object) -> list[str]:
    if not isinstance(value, (list, tuple, set)):
        return []
    allowed = set(SUPPORTED_BROWSER_IDS)
    return [item for item in dict.fromkeys(value) if isinstance(item, str) and item in allowed]


def _registry_app_paths(executable_names: Iterable[str]) -> list[Path]:
    if os.name != "nt":
        return []
    try:
        import winreg
    except ImportError:
        return []

    paths: list[Path] = []
    for executable in executable_names:
        key_path = rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{executable}"
        for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
            for candidate in (key_path, key_path.replace("SOFTWARE\\", "SOFTWARE\\WOW6432Node\\", 1)):
                try:
                    with winreg.OpenKey(root, candidate) as key:
                        value, _ = winreg.QueryValueEx(key, None)
                    if value:
                        paths.append(Path(str(value).strip('" ')))
                except (OSError, TypeError, ValueError):
                    continue
    return paths


def _windows_candidates(browser_id: str) -> list[Path]:
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    roaming = Path(os.environ.get("APPDATA", ""))
    program = Path(os.environ.get("PROGRAMFILES", ""))
    program_x86 = Path(os.environ.get("PROGRAMFILES(X86)", ""))
    mapping = {
        "chrome": (
            ("chrome.exe",),
            [local / "Google/Chrome/Application/chrome.exe", program / "Google/Chrome/Application/chrome.exe", program_x86 / "Google/Chrome/Application/chrome.exe"],
        ),
        "edge": (
            ("msedge.exe",),
            [program / "Microsoft/Edge/Application/msedge.exe", program_x86 / "Microsoft/Edge/Application/msedge.exe", local / "Microsoft/Edge/Application/msedge.exe"],
        ),
        "brave": (
            ("brave.exe",),
            [local / "BraveSoftware/Brave-Browser/Application/brave.exe", program / "BraveSoftware/Brave-Browser/Application/brave.exe", program_x86 / "BraveSoftware/Brave-Browser/Application/brave.exe"],
        ),
        "opera": (
            ("opera.exe", "launcher.exe"),
            [
                local / "Programs/Opera/launcher.exe",
                local / "Programs/Opera GX/launcher.exe",
                roaming / "Opera Software/Opera Stable/opera.exe",
                program / "Opera/launcher.exe",
                program_x86 / "Opera/launcher.exe",
            ],
        ),
    }
    executables, filesystem = mapping.get(browser_id, ((), []))
    return [*_registry_app_paths(executables), *filesystem]


def executable_candidates(browser_id: str) -> list[Path]:
    browser_id = str(browser_id or "").strip().lower()
    if browser_id not in SUPPORTED_BROWSER_IDS:
        return []
    override_id = os.environ.get("BOT_BROWSER_ID", "").strip().lower()
    override = os.environ.get("BOT_BROWSER_BINARY", "").strip()
    candidates: list[Path] = []
    if override and (not override_id or override_id == browser_id):
        candidates.append(Path(override))
    if os.name == "nt":
        candidates.extend(_windows_candidates(browser_id))
    else:
        commands = {
            "chrome": ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"),
            "edge": ("microsoft-edge", "microsoft-edge-stable"),
            "brave": ("brave-browser", "brave"),
            "opera": ("opera",),
        }[browser_id]
        import shutil

        candidates.extend(Path(path) for command in commands if (path := shutil.which(command)))

    found: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        if not str(path):
            continue
        try:
            normalized = str(path.resolve()).casefold()
        except OSError:
            normalized = str(path).casefold()
        if normalized in seen:
            continue
        seen.add(normalized)
        if path.is_file():
            found.append(path)
    return found


def _file_version(path: Path) -> str:
    if os.name != "nt":
        return ""
    escaped = str(path).replace("'", "''")
    command = f"(Get-Item -LiteralPath '{escaped}').VersionInfo.ProductVersion"
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=6,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    value = (result.stdout or "").strip()
    return value if value and value[0].isdigit() else ""


def installed_browsers() -> list[BrowserChoice]:
    result: list[BrowserChoice] = []
    for browser_id in SUPPORTED_BROWSER_IDS:
        candidates = executable_candidates(browser_id)
        if candidates:
            result.append(BrowserChoice(browser_id, BROWSER_NAMES[browser_id], candidates[0], _file_version(candidates[0])))
    return result


def choose_browser(allowed: object) -> BrowserChoice | None:
    allowed_ids = clean_browser_ids(allowed) or list(SUPPORTED_BROWSER_IDS)
    available = {item.browser_id: item for item in installed_browsers()}
    return next((available[browser_id] for browser_id in allowed_ids if browser_id in available), None)


def apply_browser_environment(choice: BrowserChoice | None) -> None:
    for key in ("BOT_BROWSER_ID", "BOT_BROWSER_NAME", "BOT_BROWSER_BINARY", "BOT_BROWSER_VERSION", "BOT_BROWSER_MAJOR"):
        os.environ.pop(key, None)
    if not choice:
        return
    os.environ["BOT_BROWSER_ID"] = choice.browser_id
    os.environ["BOT_BROWSER_NAME"] = choice.name
    os.environ["BOT_BROWSER_BINARY"] = str(choice.executable)
    os.environ["BOT_BROWSER_VERSION"] = choice.version
    if choice.major:
        os.environ["BOT_BROWSER_MAJOR"] = str(choice.major)
