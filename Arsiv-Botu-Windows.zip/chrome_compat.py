"""Chromium browser / undetected-chromedriver compatibility helpers.

The project launches several bots from separate subdirectories.  Keeping the
Chrome version detection here avoids hard-coded browser majors drifting out of
sync after Chrome auto-updates.
"""

from __future__ import annotations

import os
import re
import subprocess
import shutil
import json
import tempfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable, Optional

from browser_policy import BROWSER_NAMES, executable_candidates

_CURRENT_BROWSER_RE = re.compile(r"current browser version is\s+(\d+)", re.IGNORECASE)
_SUPPORTED_DRIVER_RE = re.compile(r"only supports chrome version\s+(\d+)", re.IGNORECASE)
_VERSION_RE = re.compile(r"(?<!\d)(\d{2,4})(?:\.\d+){1,3}(?!\d)")


def _major(value: object) -> Optional[int]:
    """Return a plausible Chrome major from a version-ish value."""
    if value is None:
        return None
    text = str(value).strip()
    match = re.match(r"^(\d{2,4})(?:\.|$)", text)
    if not match:
        return None
    try:
        major = int(match.group(1))
    except ValueError:
        return None
    return major if 40 <= major <= 9999 else None


def _registry_chrome_paths() -> list[Path]:
    if os.name != "nt":
        return []
    try:
        import winreg
    except ImportError:
        return []

    results: list[Path] = []
    keys = (
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"),
    )
    for root, key_path in keys:
        try:
            with winreg.OpenKey(root, key_path) as key:
                value, _ = winreg.QueryValueEx(key, None)
            if value:
                results.append(Path(str(value).strip('" ')))
        except (OSError, TypeError, ValueError):
            continue
    return results


def chrome_executable_candidates() -> list[Path]:
    """Return the licensed Chromium executable, with Chrome as fallback."""
    selected_id = os.environ.get("BOT_BROWSER_ID", "").strip().lower()
    if selected_id in BROWSER_NAMES:
        selected = executable_candidates(selected_id)
        if selected:
            return selected
    candidates: list[Path] = []
    candidates.extend(_registry_chrome_paths())

    local = os.environ.get("LOCALAPPDATA")
    program_files = os.environ.get("PROGRAMFILES")
    program_files_x86 = os.environ.get("PROGRAMFILES(X86)")
    for base in (local, program_files, program_files_x86):
        if base:
            candidates.append(Path(base) / "Google" / "Chrome" / "Application" / "chrome.exe")

    seen: set[str] = set()
    existing: list[Path] = []
    for path in candidates:
        try:
            normalized = str(path.resolve()).lower()
        except OSError:
            normalized = str(path).lower()
        if normalized in seen:
            continue
        seen.add(normalized)
        if path.is_file():
            existing.append(path)
    return existing


def detect_chrome_executable() -> Optional[Path]:
    """Return the Chrome binary this project should launch."""
    candidates = chrome_executable_candidates()
    return candidates[0] if candidates else None


def _uc_cache_directories(uc_module) -> list[Path]:
    """Return known undetected-chromedriver cache directories."""
    candidates: list[Path] = []
    patcher = getattr(uc_module, "Patcher", None)
    data_path = getattr(patcher, "data_path", None) if patcher is not None else None
    if data_path:
        candidates.append(Path(str(data_path)))

    for key in ("APPDATA", "LOCALAPPDATA"):
        base = os.environ.get(key)
        if base:
            candidates.append(Path(base) / "undetected_chromedriver")

    home = Path.home()
    candidates.extend([
        home / ".local" / "share" / "undetected_chromedriver",
        home / "AppData" / "Roaming" / "undetected_chromedriver",
        home / "AppData" / "Local" / "undetected_chromedriver",
    ])

    unique: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        key = str(path).lower()
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return unique


def clear_undetected_chromedriver_cache(uc_module, log: Optional[Callable[[str], None]] = None) -> list[str]:
    """Delete stale UC driver binaries after a proven browser/driver mismatch.

    We deliberately do this only after Selenium explicitly reports that the
    cached driver major differs from the installed browser major.
    """
    logger = log or (lambda _message: None)
    removed: list[str] = []
    for cache_dir in _uc_cache_directories(uc_module):
        if not cache_dir.exists():
            continue
        try:
            for path in cache_dir.rglob("*"):
                if not path.is_file():
                    continue
                name = path.name.lower()
                if "chromedriver" not in name and "undetected_chromedriver" not in name:
                    continue
                try:
                    path.unlink()
                    removed.append(str(path))
                except OSError:
                    # A currently-running driver can be locked on Windows.
                    pass
        except OSError:
            continue
    if removed:
        logger(f"Eski undetected_chromedriver cache temizlendi ({len(removed)} dosya).")
    return removed


def _powershell_file_version(path: Path) -> Optional[str]:
    """Read chrome.exe's actual ProductVersion without launching Chrome."""
    if os.name != "nt":
        return None
    escaped = str(path).replace("'", "''")
    command = f"(Get-Item -LiteralPath '{escaped}').VersionInfo.ProductVersion"
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=6,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    value = (result.stdout or "").strip()
    return value or None


def _directory_version(path: Path) -> Optional[str]:
    """Fallback for normal Chrome installs where version folders sit by chrome.exe."""
    try:
        versions: list[tuple[tuple[int, ...], str]] = []
        for child in path.parent.iterdir():
            if not child.is_dir() or not _VERSION_RE.fullmatch(child.name):
                continue
            parts = tuple(int(part) for part in child.name.split("."))
            versions.append((parts, child.name))
        if versions:
            versions.sort(reverse=True)
            return versions[0][1]
    except (OSError, ValueError):
        pass
    return None


def _registry_blbeacon_major() -> Optional[int]:
    if os.name != "nt":
        return None
    try:
        import winreg
    except ImportError:
        return None

    keys = (
        (winreg.HKEY_CURRENT_USER, r"Software\Google\Chrome\BLBeacon"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Google\Chrome\BLBeacon"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Google\Chrome\BLBeacon"),
    )
    for root, key_path in keys:
        try:
            with winreg.OpenKey(root, key_path) as key:
                value, _ = winreg.QueryValueEx(key, "version")
            major = _major(value)
            if major:
                return major
        except (OSError, TypeError, ValueError):
            continue
    return None


def detect_chrome_major() -> Optional[int]:
    """Detect the major of the selected Chromium browser."""
    configured = _major(os.environ.get("BOT_BROWSER_MAJOR"))
    if configured:
        return configured
    for executable in chrome_executable_candidates():
        version = _powershell_file_version(executable) or _directory_version(executable)
        major = _major(version)
        if major:
            return major
    return _registry_blbeacon_major()


_CFT_KNOWN_GOOD = "https://googlechromelabs.github.io/chrome-for-testing/known-good-versions-with-downloads.json"
_DRIVER_VERSION_RE = re.compile(r"ChromeDriver\s+(\d+)(?:\.\d+){1,3}", re.IGNORECASE)


def detect_chrome_version() -> Optional[str]:
    """Return the full version of the licensed browser binary."""
    configured = os.environ.get("BOT_BROWSER_VERSION", "").strip()
    if configured and _VERSION_RE.fullmatch(configured):
        return configured
    for executable in chrome_executable_candidates():
        version = _powershell_file_version(executable) or _directory_version(executable)
        if version and _VERSION_RE.fullmatch(version.strip()):
            return version.strip()
    return None


def _driver_major(path: Path) -> Optional[int]:
    try:
        result = subprocess.run(
            [str(path), "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=8,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    match = _DRIVER_VERSION_RE.search(result.stdout or "")
    return int(match.group(1)) if match else None


def ensure_matching_chromedriver(
    cache_root: Path,
    *,
    chrome_major: int,
    chrome_version: Optional[str] = None,
    log: Optional[Callable[[str], None]] = None,
) -> Path:
    """Download and cache an official ChromeDriver with the same major as Chrome.

    UC 3.5.5 can reuse an old patched executable even when ``version_main`` is
    correct. Passing a verified custom driver path prevents that stale-cache
    path entirely.
    """
    logger = log or (lambda _message: None)
    cache_dir = Path(cache_root) / f"chrome_{chrome_major}"
    cache_dir.mkdir(parents=True, exist_ok=True)
    driver_path = cache_dir / "chromedriver.exe"

    if driver_path.is_file() and _driver_major(driver_path) == chrome_major:
        logger(f"Doğrulanmış ChromeDriver {chrome_major} kullanılıyor: {driver_path}")
        return driver_path

    try:
        if driver_path.exists():
            driver_path.unlink()
    except OSError:
        pass

    logger(f"ChromeDriver {chrome_major} Google Chrome-for-Testing kaynağından indiriliyor...")
    request = urllib.request.Request(
        _CFT_KNOWN_GOOD,
        headers={"User-Agent": "Mozilla/5.0"},
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.load(response)

    versions = payload.get("versions") or []
    exact = None
    if chrome_version:
        exact = next((item for item in versions if item.get("version") == chrome_version), None)

    def version_key(item):
        try:
            return tuple(int(part) for part in str(item.get("version", "0")).split("."))
        except ValueError:
            return (0,)

    candidates = [
        item for item in versions
        if _major(item.get("version")) == chrome_major
        and (item.get("downloads") or {}).get("chromedriver")
    ]
    selected = exact if exact and (exact.get("downloads") or {}).get("chromedriver") else None
    if selected is None and candidates:
        selected = max(candidates, key=version_key)
    if selected is None:
        raise RuntimeError(f"Chrome {chrome_major} için Chrome-for-Testing ChromeDriver bulunamadı.")

    downloads = (selected.get("downloads") or {}).get("chromedriver") or []
    # Chrome-for-Testing currently exposes win64 and sometimes win32. Prefer win64.
    entry = next((item for item in downloads if item.get("platform") == "win64"), None)
    if entry is None:
        entry = next((item for item in downloads if item.get("platform") == "win32"), None)
    if entry is None or not entry.get("url"):
        raise RuntimeError(f"Chrome {chrome_major} için Windows ChromeDriver indirme bağlantısı bulunamadı.")

    logger(f"İndirilecek ChromeDriver sürümü: {selected.get('version')}")
    zip_path = cache_dir / "chromedriver.zip"
    urllib.request.urlretrieve(entry["url"], zip_path)
    try:
        with zipfile.ZipFile(zip_path, "r") as archive:
            member = next(
                (name for name in archive.namelist() if name.lower().endswith("/chromedriver.exe") or name.lower() == "chromedriver.exe"),
                None,
            )
            if not member:
                raise RuntimeError("İndirilen arşivde chromedriver.exe bulunamadı.")
            with archive.open(member) as src, open(driver_path, "wb") as dst:
                shutil.copyfileobj(src, dst)
    finally:
        try:
            zip_path.unlink()
        except OSError:
            pass

    downloaded_major = _driver_major(driver_path)
    if downloaded_major != chrome_major:
        try:
            driver_path.unlink()
        except OSError:
            pass
        raise RuntimeError(
            f"İndirilen ChromeDriver major={downloaded_major}; beklenen major={chrome_major}."
        )
    logger(f"ChromeDriver {chrome_major} doğrulandı: {driver_path}")
    return driver_path


def browser_major_from_error(error: BaseException | str) -> Optional[int]:
    """Extract the browser major Selenium reports in SessionNotCreated errors."""
    match = _CURRENT_BROWSER_RE.search(str(error))
    if not match:
        return None
    return _major(match.group(1))


def driver_major_from_error(error: BaseException | str) -> Optional[int]:
    match = _SUPPORTED_DRIVER_RE.search(str(error))
    if not match:
        return None
    return _major(match.group(1))


def explain_chrome_start_error(error: BaseException | str) -> str:
    """Return a short actionable Turkish explanation for common UC start failures."""
    browser = browser_major_from_error(error)
    driver = driver_major_from_error(error)
    if browser and driver and browser != driver:
        return (
            f"Chrome/ChromeDriver sürüm uyuşmazlığı: tarayıcı Chrome {browser}, "
            f"hazırlanan sürücü Chrome {driver} bekliyor. Bot artık gerçek Chrome "
            "sürümünü algılayıp yeniden deniyor; hata sürerse runtime'ı yeniden kurun."
        )

    text = str(error).lower()
    if "user data directory is already in use" in text or "profile in use" in text:
        return "Chrome profil klasörü başka bir Chrome işlemi tarafından kullanılıyor. İlgili bot Chrome'unu kapatıp yeniden deneyin."
    if "cannot connect to chrome" in text or "chrome not reachable" in text:
        return "Chrome başlatıldı ancak ChromeDriver tarayıcıya bağlanamadı. Yetim Chrome işlemi veya bozuk profil kilidi olabilir."
    if "session not created" in text:
        return "Chrome oturumu oluşturulamadı. En olası neden Chrome/ChromeDriver sürümü veya kilitli Chrome profilidir."
    return str(error).strip() or error.__class__.__name__ if isinstance(error, BaseException) else str(error)


def start_undetected_chrome(
    uc_module,
    options_factory: Callable[[], object],
    *,
    version_main: Optional[int] = None,
    log: Optional[Callable[[str], None]] = None,
    **chrome_kwargs,
):
    """Start UC with a fresh options object and one safe version-mismatch retry.

    ``undetected_chromedriver`` marks ChromeOptions after use, so every retry
    must receive a newly-created options object.  If Selenium tells us the
    actual browser major, that value is preferred for the second attempt.
    """
    logger = log or (lambda _message: None)
    detected = detect_chrome_major()
    browser_id = os.environ.get("BOT_BROWSER_ID", "chrome").strip().lower()
    browser_name = BROWSER_NAMES.get(browser_id, "Chromium")
    browser_binary = detect_chrome_executable()
    requested = _major(version_main)
    # An explicitly requested major wins. Messenger passes the currently
    # validated Chrome major so UC cannot silently fall back to an older cache.
    initial_major = requested or detected

    attempts: list[Optional[int]] = [initial_major]
    if initial_major is None:
        attempts = [None]

    tried: set[Optional[int]] = set()
    last_error: Optional[BaseException] = None

    while attempts:
        major = attempts.pop(0)
        if major in tried:
            continue
        tried.add(major)
        options = options_factory()
        kwargs = dict(chrome_kwargs)
        # UC's user_multi_procs mode intentionally reuses the most recent patched
        # binary. That is exactly how a cached ChromeDriver 151 was reused while
        # Chrome 153 was installed, so never enable it in the compatibility layer.
        kwargs.pop("user_multi_procs", None)
        kwargs["options"] = options
        if major:
            kwargs["version_main"] = major
            logger(f"{browser_name} {major} için uyumlu sürücü hazırlanıyor...")
        else:
            logger("Chrome sürümü otomatik algılamayla başlatılıyor...")

        try:
            if browser_binary and not kwargs.get("browser_executable_path"):
                kwargs["browser_executable_path"] = str(browser_binary)
            return uc_module.Chrome(**kwargs)
        except Exception as exc:  # UC/Selenium expose several exception types here.
            last_error = exc
            actual_major = browser_major_from_error(exc)
            driver_major = driver_major_from_error(exc)
            if actual_major and driver_major and actual_major != driver_major:
                logger(
                    f"Eski ChromeDriver {driver_major} bulundu; kurulu tarayıcı Chrome "
                    f"{actual_major}. Eski UC cache temizleniyor..."
                )
                clear_undetected_chromedriver_cache(uc_module, logger)
            if actual_major and actual_major not in tried:
                logger(
                    f"Selenium gerçek tarayıcıyı Chrome {actual_major} olarak bildirdi. "
                    "Doğru sürücüyle bir kez yeniden deneniyor..."
                )
                attempts.insert(0, actual_major)
                continue
            raise

    if last_error is not None:
        raise last_error
    raise RuntimeError("Chrome başlatma denemesi oluşturulamadı")


def safe_quit_undetected(driver) -> None:
    """Quit once and neutralize UC's second destructor quit on Windows."""
    if driver is None:
        return
    try:
        driver.quit()
    except Exception:
        pass
    try:
        driver.quit = lambda: None
    except Exception:
        pass
