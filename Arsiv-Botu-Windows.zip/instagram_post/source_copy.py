"""Instagram kaynaklarını sıralı kuyruk ve geçici dosyayla aktarır.

Tarayıcıya yalnızca çağıran worker dokunur. Kaynak hesap çerezleri bellekte
kalır; kaynak geçmişi hedef hesabın klasöründe atomik olarak saklanır.
"""

from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from http.cookiejar import Cookie, CookieJar
import json
import os
from pathlib import Path
import re
import tempfile
import threading
import time
from typing import Callable
from urllib.parse import urlsplit


SOURCE_DEFAULTS = {
    "sourceMode": "local",
    "sourceProfile": "",
    "sourceLinks": "",
    "sourceLimit": 20,
    "sourceOrder": "listed",
    "captionMode": "source",
    "forbiddenWords": "",
}
MAX_TRANSFER_BYTES = 250 * 1024 * 1024
MAX_TRANSFER_SECONDS = 300
MAX_SOURCE_ITEMS = 1000
MAX_SCROLL_ROUNDS = 1200
SCROLL_LOAD_POLLS = 12
SCROLL_LOAD_POLL_SECONDS = 1.3
# Instagram's Reels grid can take several rounds to append the next batch.
# A short run of unchanged DOM nodes is not proof that the profile ended.
# If Instagram stops appending Reels, keep the current batch and move on after
# five minutes. This is time based rather than scroll-count based because one
# lazy-load round can take very different amounts of time.
MAX_STAGNANT_SECONDS = 5 * 60
_HOSTS = {"instagram.com", "www.instagram.com"}
_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_PROFILE_PATTERN = re.compile(r"^[A-Za-z0-9_](?:[A-Za-z0-9_.]{0,28}[A-Za-z0-9_])?$")
_RESERVED_PROFILES = {"accounts", "explore", "direct", "reel", "reels", "p", "stories", "create"}


class SourceCopyError(RuntimeError):
    """Günlüklere güvenle yazılabilecek kaynak hazırlama hatası."""


class SourceCancelled(SourceCopyError):
    pass


class SourceFiltered(SourceCopyError):
    pass


class SourceUnavailable(SourceCopyError):
    """Tek bir kaynak Reel'e özgü, sıradaki öğeye geçilebilen hata."""


def _unavailable_message(error: Exception, reel_id: str) -> str:
    """yt-dlp ayrıntılarını/signed URL'leri göstermeden güvenli neden üret."""
    message = str(error).casefold()
    if any(token in message for token in ("login", "cookie", "authentication", "checkpoint")):
        reason = "mevcut Instagram oturumu bu içeriğe erişemedi"
    elif any(token in message for token in ("private", "unavailable", "not found", "removed", "deleted")):
        reason = "kaynak silinmiş, gizli veya erişime kapatılmış"
    elif any(token in message for token in ("requested format", "format is not available", "no video formats")):
        reason = "Instagram uyumlu bir video akışı sunmadı"
    elif any(token in message for token in ("timeout", "timed out")):
        reason = "Instagram medya bağlantısı zaman aşımına uğradı"
    else:
        reason = "yt-dlp bu Reel'in medya akışını çözemedi"
    return f"Reel {reel_id} indirilemedi: {reason}. Sıradaki Reel deneniyor."


def _instagram_url(value: str):
    try:
        parsed = urlsplit(value)
        if (
            parsed.scheme != "https"
            or parsed.hostname not in _HOSTS
            or parsed.username is not None
            or parsed.password is not None
            or parsed.port is not None
            or "\\" in value
        ):
            raise ValueError
        return parsed
    except (ValueError, TypeError):
        raise ValueError("Yalnızca https://www.instagram.com bağlantıları kullanılabilir.") from None


def _reel_url(value: str) -> tuple[str, str]:
    parsed = _instagram_url(value.strip())
    # Profil ızgarası artık /kullanici/reel/KOD/ bağlantıları da üretiyor.
    # Her iki biçimi aynı kimliğe indirgemek geçmişteki tekrar kontrolünü korur.
    match = re.fullmatch(r"/(?:([^/]+)/)?reel/([A-Za-z0-9_-]{1,64})/?", parsed.path)
    if not match:
        raise ValueError("Her kaynak bağlantısı bir Instagram /reel/ bağlantısı olmalı.")
    if match.group(1):
        _profile(match.group(1))
    reel_id = match.group(2)
    return reel_id, f"https://www.instagram.com/reel/{reel_id}/"


def _profile(value: str) -> str:
    value = value.strip()
    if not value:
        return ""
    if "://" in value:
        parsed = _instagram_url(value)
        match = re.fullmatch(r"/([^/]+)(?:/reels)?/?", parsed.path)
        if not match:
            raise ValueError("Kaynak profil bağlantısı geçerli değil.")
        value = match.group(1)
    else:
        value = value.removeprefix("@")
    if not _PROFILE_PATTERN.fullmatch(value) or ".." in value or value.lower() in _RESERVED_PROFILES:
        raise ValueError("Kaynak profil için geçerli bir Instagram kullanıcı adı girin.")
    return value.lower()


def normalize_source_config(payload: dict) -> dict:
    """Eksik taslak alanlarına izin verir; girilmiş alanları kesin doğrular."""
    result = dict(SOURCE_DEFAULTS)
    for key in result:
        if key in payload:
            result[key] = payload[key]
    for key, allowed in (
        ("sourceMode", {"local", "instagram"}),
        ("sourceOrder", {"listed", "reverse"}),
        ("captionMode", {"source", "custom", "empty"}),
    ):
        if not isinstance(result[key], str) or result[key] not in allowed:
            raise ValueError(f"Geçersiz kaynak ayarı: {key}.")
    limit = result["sourceLimit"]
    if (isinstance(limit, bool) or not re.fullmatch(r"\d+", str(limit))
            or not 1 <= int(limit) <= MAX_SOURCE_ITEMS):
        raise ValueError(f"Kaynak video sınırı 1 ile {MAX_SOURCE_ITEMS} arasında olmalı.")
    result["sourceLimit"] = int(limit)
    for key in ("sourceProfile", "sourceLinks", "forbiddenWords"):
        if not isinstance(result[key], str):
            raise ValueError(f"{key} metin olmalı.")
    result["sourceProfile"] = _profile(result["sourceProfile"])
    links, seen = [], set()
    for line in result["sourceLinks"].splitlines():
        if not line.strip():
            continue
        reel_id, url = _reel_url(line)
        if reel_id not in seen:
            seen.add(reel_id)
            links.append(url)
    if len(links) > 1000:
        raise ValueError("Tek listede en fazla 1000 kaynak bağlantısı kullanılabilir.")
    result["sourceLinks"] = "\n".join(links)
    result["forbiddenWords"] = result["forbiddenWords"].strip()
    return result


class _SilentLogger:
    # yt-dlp hata mesajları imzalı medya bağlantısı/oturum bilgisi içerebilir.
    def debug(self, _message):
        pass

    info = warning = error = debug


class InstagramSourceCopy:
    def __init__(self, root: Path, stop: threading.Event, log: Callable[[str], None]):
        self.root = Path(root)
        self.stop = stop
        self.log = log
        self._lock = threading.RLock()
        self._queue: list[dict] = []
        self._signature = None
        self._skipped: set[str] = set()
        self.manual_pause = None
        self.last_scan_stalled = False

    def _check_cancelled(self):
        if self.stop.is_set():
            raise SourceCancelled("Kaynak aktarımı durduruldu.")

    def refresh(self):
        with self._lock:
            self._signature = None
            self._queue = []
            self._skipped.clear()

    def skip(self, item: dict):
        reel_id, _ = self._identity(item)
        with self._lock:
            self._skipped.add(reel_id)

    @staticmethod
    def _identity(item: dict) -> tuple[str, str]:
        reel_id, url = _reel_url(str(item.get("url", "")))
        if str(item.get("id", "")) != reel_id:
            raise ValueError("Kaynak kimliği bağlantıyla eşleşmiyor.")
        return reel_id, url

    def _read_history(self) -> dict:
        path = self.root / "source_history.json"
        if not path.exists():
            return {"published": {}, "pending": {}}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError
            for key in ("published", "pending"):
                if not isinstance(data.get(key), dict):
                    raise ValueError
                for reel_id, record in data[key].items():
                    if not _ID_PATTERN.fullmatch(reel_id) or not isinstance(record, dict):
                        raise ValueError
            return data
        except (OSError, ValueError, TypeError):
            raise SourceCopyError("Kaynak geçmişi okunamadı; tekrar paylaşımı önlemek için işlem durdu.") from None

    def history(self) -> dict:
        with self._lock:
            return deepcopy(self._read_history())

    def _write_history(self, history: dict):
        temporary_path = None
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.root, prefix=".source-history-", suffix=".tmp", delete=False) as handle:
                temporary_path = Path(handle.name)
                json.dump(history, handle, ensure_ascii=False, indent=2)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_path, self.root / "source_history.json")
        except OSError:
            raise SourceCopyError("Kaynak paylaşım geçmişi kaydedilemedi; işlem durduruldu.") from None
        finally:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)

    @staticmethod
    def _record(reel_id: str, url: str) -> dict:
        return {"id": reel_id, "url": url, "updatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds")}

    def mark_pending(self, item: dict):
        reel_id, url = self._identity(item)
        with self._lock:
            history = self._read_history()
            if reel_id in history["published"]:
                raise SourceCopyError("Bu kaynak daha önce paylaşıldı.")
            history["pending"][reel_id] = self._record(reel_id, url)
            self._write_history(history)

    def mark_published(self, item: dict):
        reel_id, url = self._identity(item)
        with self._lock:
            history = self._read_history()
            history["published"][reel_id] = self._record(reel_id, url)
            history["pending"].pop(reel_id, None)
            self._write_history(history)

    def resolve_pending(self, reel_id: str, published: bool):
        if not isinstance(published, bool):
            raise ValueError("Paylaşım sonucu doğru veya yanlış olmalı.")
        with self._lock:
            history = self._read_history()
            record = history["pending"].get(reel_id)
            if record is None:
                raise ValueError("Bekleyen kaynak kaydı bulunamadı.")
            if published:
                history["published"][reel_id] = self._record(reel_id, record["url"])
            del history["pending"][reel_id]
            self._write_history(history)
            self._skipped.discard(reel_id)

    def _collect_profile(self, driver, profile: str, limit: int, excluded_ids: set[str] | None = None) -> list[dict]:
        items, seen = [], set()
        excluded_ids = excluded_ids or set()
        last_reported_scan_count = 0
        self.last_scan_stalled = False

        def cycle_expired() -> bool:
            check = getattr(self, "scan_cycle_expired", None)
            return bool(check and check())

        def wait_for_manual_browser() -> bool:
            """Pause collection while the archive worker exposes Chrome for manual scrolling."""
            pause = getattr(self, "manual_pause", None)
            paused = False
            while pause is not None and pause.is_set():
                paused = True
                self._check_cancelled()
                self.stop.wait(0.25)
            return paused

        def collect_visible() -> int:
            """Collect the currently rendered grid without failing on React redraws."""
            added = 0
            try:
                elements = driver.find_elements("css selector", "main a[href*='/reel/']")
            except Exception:
                # Instagram occasionally replaces the complete grid while a lazy-load
                # request is finishing. The next poll gets a fresh element collection.
                return 0
            for element in elements:
                try:
                    reel_id, url = _reel_url(element.get_attribute("href") or "")
                except Exception:
                    # A WebElement can become stale between find_elements and
                    # get_attribute. One stale tile must not abort a long scan.
                    continue
                if reel_id not in seen:
                    seen.add(reel_id)
                    added += 1
                    # seen'e kaydettikten sonra limit kontrolü yap;
                    # seen sayacı scrolling mantığı için kritik, limit dolsa bile güncellenmeli.
                    if reel_id not in excluded_ids and len(items) < limit:
                        items.append({"id": reel_id, "url": url, "description": ""})
            return added

        try:
            self._check_cancelled()
            wait_for_manual_browser()
            try:
                driver.get(f"https://www.instagram.com/{profile}/reels/")
            except Exception as error:
                if error.__class__.__name__ != "TimeoutException":
                    raise
                # Chrome may time out because an analytics/media request never
                # finishes even though the Reels grid is already usable.
                self.log("Kaynak profil yüklemesi zaman aşımına uğradı; görünen Reeller üzerinden tarama sürdürülüyor.")
            if self.stop.wait(2):
                self._check_cancelled()
            stagnant = 0
            stagnant_since = time.monotonic()
            scroll_attempt = 0
            for _ in range(MAX_SCROLL_ROUNDS):
                self._check_cancelled()
                if wait_for_manual_browser():
                    # Manual recovery time must not count against the
                    # five-minute stall window.
                    stagnant_since = time.monotonic()
                if cycle_expired():
                    return items
                if any(part in str(driver.current_url) for part in ("/accounts/login", "/challenge/", "/checkpoint/")):
                    raise SourceCopyError("Kaynak profili okumak için Instagram girişini/doğrulamasını tamamlayın.")
                collect_visible()
                if len(items) >= limit:
                    return items

                before_scroll = len(seen)

                # Instagram'ın Reels sayfası virtualized bir grid kullanır.
                # window.scrollBy tek başına yeterli değil; farklı yöntemler
                # sırayla denenerek lazy-load tetiklenir.
                scroll_method = scroll_attempt % 4
                if scroll_method == 0:
                    # En güvenilir: son reel bağlantısına scrollIntoView
                    driver.execute_script(
                        "const links = document.querySelectorAll('main a[href*=\"/reel/\"]');"
                        "if (links.length) links[links.length - 1].scrollIntoView({behavior:'instant',block:'end'});"
                    )
                elif scroll_method == 1:
                    # documentElement'in scrollTop'unu artır
                    driver.execute_script(
                        "document.documentElement.scrollTop += Math.max(800, Math.floor(window.innerHeight * 0.9));"
                    )
                elif scroll_method == 2:
                    # Sayfanın en altına atla
                    driver.execute_script(
                        "window.scrollTo(0, document.documentElement.scrollHeight);"
                    )
                else:
                    # main veya article konteynerini kaydır
                    driver.execute_script(
                        "const el = document.querySelector('main') || document.querySelector('article') || document.body;"
                        "el.scrollTop += Math.max(800, Math.floor(window.innerHeight * 0.9));"
                        "window.scrollBy(0, Math.max(800, Math.floor(window.innerHeight * 0.9)));"
                    )
                scroll_attempt += 1

                for _poll in range(SCROLL_LOAD_POLLS):
                    if wait_for_manual_browser():
                        stagnant_since = time.monotonic()
                    if self.stop.wait(SCROLL_LOAD_POLL_SECONDS):
                        self._check_cancelled()
                    collect_visible()
                    if cycle_expired():
                        return items
                    if len(items) >= limit:
                        return items
                    if len(seen) > before_scroll:
                        break

                if len(seen) > before_scroll:
                    stagnant = 0
                    stagnant_since = time.monotonic()
                    if len(seen) - last_reported_scan_count >= 25:
                        last_reported_scan_count = len(seen)
                        self.log(
                            f"Kaynak taraması sürüyor: {len(seen)} Reel incelendi, "
                            f"{len(items)}/{limit} yeni Reel bulundu."
                        )
                else:
                    stagnant += 1
                    elapsed = time.monotonic() - stagnant_since
                    if elapsed >= MAX_STAGNANT_SECONDS:
                        self.last_scan_stalled = True
                        self.log(
                            f"Kaynak taraması {MAX_STAGNANT_SECONDS // 60} dakika boyunca ilerlemedi; "
                            f"{len(items)} yeni Reel bulundu, bulunanlar indirilecek."
                        )
                        break
        except SourceCopyError:
            raise
        except Exception:
            raise SourceCopyError("Instagram kaynak profili okunamadı. Tarayıcı oturumunu ve profil erişimini kontrol edin.") from None
        if self.last_scan_stalled:
            return items
        if not items:
            if seen:
                self.log(f"Kaynak profil sonuna ulaşıldı: {len(seen)} Reel incelendi, yeni Reel bulunamadı.")
                return []
            raise SourceCopyError("Kaynak profilde erişilebilir Reels bulunamadı. Profil adını ve hesap erişimini kontrol edin.")
        if len(items) < limit:
            self.log(
                f"Kaynak profil sonuna ulaşıldı: {len(seen)} Reel incelendi, "
                f"{len(items)}/{limit} yeni Reel bulundu."
            )
        return items

    def next_item(self, driver, config: dict) -> dict | None:
        self._check_cancelled()
        cfg = normalize_source_config(config)
        if cfg["sourceMode"] == "local":
            return None
        if not cfg["sourceLinks"] and not cfg["sourceProfile"]:
            raise ValueError("Bir Instagram kaynak profili veya Reels bağlantı listesi girin.")
        signature = json.dumps(cfg, sort_keys=True)
        with self._lock:
            collect = signature != self._signature
        if collect:
            if cfg["sourceLinks"]:
                items = []
                for url in cfg["sourceLinks"].splitlines()[:cfg["sourceLimit"]]:
                    reel_id, url = _reel_url(url)
                    items.append({"id": reel_id, "url": url, "description": ""})
            else:
                self.log(f"Kaynak profil taranıyor: @{cfg['sourceProfile']}")
                with self._lock:
                    history = self._read_history()
                    excluded_ids = set(history["published"]) | set(history["pending"])
                items = self._collect_profile(
                    driver,
                    cfg["sourceProfile"],
                    cfg["sourceLimit"],
                    excluded_ids,
                )
            if cfg["sourceOrder"] == "reverse":
                items.reverse()
            for ordinal, item in enumerate(items):
                item["ordinal"] = ordinal
            with self._lock:
                self._queue = items
                self._signature = signature
                self._skipped.clear()
            self.log(f"Kaynak kuyruğu hazır: {len(items)} Reels bağlantısı.")
        with self._lock:
            history = self._read_history()
            for item in self._queue:
                reel_id = item["id"]
                if reel_id not in history["published"] and reel_id not in history["pending"] and reel_id not in self._skipped:
                    return dict(item)
            # Kuyruk tüketildi. Bir sonraki Başlat işleminde aynı ayarlar
            # kullanılsa bile profili yeniden tara; kaynak hesap bu sırada yeni
            # Reels eklemiş veya geçmiştekilerin altında yeni adaylar bulunmuş olabilir.
            self._signature = None
            self._queue = []
        return None

    @staticmethod
    def _cookies(driver) -> CookieJar:
        jar = CookieJar()
        for raw in driver.get_cookies():
            domain = str(raw.get("domain", "")).lower()
            stripped = domain.lstrip(".")
            if stripped != "instagram.com" and not stripped.endswith(".instagram.com"):
                continue
            name, value = raw.get("name"), raw.get("value")
            if not isinstance(name, str) or not isinstance(value, str):
                continue
            expires = raw.get("expiry")
            jar.set_cookie(Cookie(
                version=0, name=name, value=value, port=None, port_specified=False,
                domain=domain, domain_specified=domain.startswith("."), domain_initial_dot=domain.startswith("."),
                path=raw.get("path") or "/", path_specified=True, secure=bool(raw.get("secure", True)),
                expires=int(expires) if expires is not None else None, discard=expires is None,
                comment=None, comment_url=None, rest={"HttpOnly": bool(raw.get("httpOnly"))}, rfc2109=False,
            ))
        return jar

    @staticmethod
    def _caption(description: str, config: dict, ordinal: int) -> str:
        mode = config.get("captionMode", "source")
        if mode == "empty":
            return ""
        if mode == "source":
            return description
        texts = config.get("texts", "")
        lines = texts.splitlines() if isinstance(texts, str) else texts if isinstance(texts, list) else []
        pool = [str(line).strip() for line in lines if str(line).strip()]
        return pool[ordinal % len(pool)] if pool else ""

    @contextmanager
    def transfer(self, driver, item: dict, config: dict):
        """Geçici MP4 ve açıklamayı verir; blok bitince dosyaları temizler."""
        self._check_cancelled()
        _, url = self._identity(item)
        cfg = {**config, **normalize_source_config(config)}
        try:
            import yt_dlp
        except ImportError:
            raise SourceCopyError("Kaynak aktarımı için yt-dlp eksik. Bot bağımlılıklarını yükleyin.") from None
        try:
            from yt_dlp.utils import DownloadError as YtDlpDownloadError
        except ImportError:
            # Birim testlerinin küçük yt-dlp sahtesi utils alt modülünü içermez.
            YtDlpDownloadError = ()
        started = time.monotonic()

        def check_progress(progress=None):
            self._check_cancelled()
            if time.monotonic() - started > MAX_TRANSFER_SECONDS:
                raise SourceUnavailable(f"Reel {item['id']} aktarımı süre sınırını aştı. Sıradaki Reel deneniyor.")
            progress = progress or {}
            for key in ("downloaded_bytes", "total_bytes", "total_bytes_estimate"):
                if (progress.get(key) or 0) > MAX_TRANSFER_BYTES:
                    raise SourceUnavailable(f"Reel {item['id']} 250 MB aktarım sınırını aşıyor. Sıradaki Reel deneniyor.")

        with tempfile.TemporaryDirectory(prefix="instagram-source-") as temporary:
            folder = Path(temporary).resolve()
            options = {
                # Sesli + video birleşik en iyi MP4'ü tercih et.
                # ffmpeg kuruluysa DASH (ayrı video+audio) akışları otomatik birleştirilir.
                # Sıralama: sesli birleşik mp4 → sesli birleşik herhangi → DASH birleştirmeli → fallback
                "format": (
                    "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio"
                    "/best[ext=mp4][vcodec!=none][acodec!=none]"
                    "/best[vcodec!=none][acodec!=none]"
                    "/best[ext=mp4]/best"
                ),
                "merge_output_format": "mp4",  # Birleştirilmiş çıktıyı MP4 olarak kaydet
                "outtmpl": str(folder / "source.%(ext)s"),
                "noplaylist": True,
                "max_filesize": MAX_TRANSFER_BYTES,
                "socket_timeout": 45,
                "retries": 5,
                "extractor_retries": 3,
                "fragment_retries": 5,
                "file_access_retries": 1,
                "quiet": True,
                "no_warnings": True,
                "noprogress": True,
                "fixup": "detect_or_warn",  # 'never' yerine: bozuk container'ı ffmpeg ile onar
                "logger": _SilentLogger(),
                "progress_hooks": [check_progress],
                "cachedir": False,
            }
            # Archive downloads supply their bundled FFmpeg/merge preferences;
            # Post Bot defaults remain unchanged.
            options.update(getattr(self, "transfer_options", {}))
            try:
                with yt_dlp.YoutubeDL(options) as downloader:
                    for cookie in self._cookies(driver):
                        downloader.cookiejar.set_cookie(cookie)
                    # extract_info ile forbidden-words için ön bilgi al; URL'ler
                    # henüz indirilmemişse geçerlidir. Ardından tek çağrıyla indir.
                    info = downloader.extract_info(url, download=False)
                    check_progress()
                    if not isinstance(info, dict) or info.get("_type") in {"playlist", "multi_video"} or "entries" in info:
                        raise SourceUnavailable(f"Reel {item['id']} tek bir video döndürmedi. Sıradaki Reel deneniyor.")
                    description = str(info.get("description") or item.get("description") or "")
                    item["description"] = description
                    formats = info.get("formats") or []
                    audio_codecs = [entry.get("acodec") for entry in formats if isinstance(entry, dict)]
                    if info.get("has_audio") is False:
                        item["has_audio"] = False
                    elif info.get("acodec") not in (None, "none") or any(codec not in (None, "none") for codec in audio_codecs):
                        item["has_audio"] = True
                    words = [word.strip().casefold() for word in re.split(r"[,\n]", cfg["forbiddenWords"]) if word.strip()]
                    if any(word in description.casefold() for word in words):
                        self.skip(item)
                        raise SourceFiltered("Kaynak video açıklama filtresi nedeniyle atlandı.")
                    # İki aşamalı extract+process yerine tek seferde indir.
                    # process_ie_result eski yt-dlp sürümlerinde URL'leri yeniden
                    # çözümlemeden kullanıyordu; modern yt-dlp'de extract_info(download=True)
                    # medya URL'lerini taze tutarak hem bilgiyi hem dosyayı üretiyor.
                    downloaded = downloader.extract_info(url, download=True)
                    check_progress()
                    if not isinstance(downloaded, dict):
                        raise SourceUnavailable(f"Reel {item['id']} hazırlanamadı. Sıradaki Reel deneniyor.")
                    # Prefer postprocessed paths, not a guessed pre-merge filename.
                    candidates = list(filter(None, (
                        downloaded.get("filepath"),
                        downloaded.get("_filename"),
                    )))
                    for entry in downloaded.get("requested_downloads") or []:
                        if isinstance(entry, dict) and entry.get("filepath"):
                            candidates.append(entry["filepath"])
                    candidates.append(downloader.prepare_filename(downloaded))
                    path = None
                    for candidate in candidates:
                        resolved = Path(candidate).resolve()
                        if not resolved.is_relative_to(folder):
                            raise SourceCopyError("Kaynak video geçici aktarım klasörü dışında oluşturuldu.")
                        extensions = {".mp4", ".mkv", ".webm"} if getattr(self, "transfer_options", None) else {".mp4"}
                        if resolved.is_file() and resolved.suffix.lower() in extensions:
                            path = resolved
                            break
                    if path is None or not 0 < path.stat().st_size <= MAX_TRANSFER_BYTES:
                        raise SourceUnavailable(
                            f"Reel {item['id']} için geçerli MP4 oluşturulamadı veya dosya boyutu sınırı aşıldı. "
                            "Sıradaki Reel deneniyor."
                        )
                    caption = self._caption(description, cfg, int(item.get("ordinal", 0)))
            except SourceCopyError:
                raise
            except Exception as error:
                self._check_cancelled()
                if YtDlpDownloadError and isinstance(error, YtDlpDownloadError):
                    raise SourceUnavailable(_unavailable_message(error, item["id"])) from None
                raise SourceCopyError("Kaynak video alınamadı. Bağlantının erişilebilirliğini, Instagram oturumunu ve yt-dlp sürümünü kontrol edin.") from None
            # Çağıranın yayın hatalarını kaynak hatasına dönüştürmeyin.
            yield path, caption
