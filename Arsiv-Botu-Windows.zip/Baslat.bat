@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Ilk kullanim kurulumu baslatiliyor...
  call Kurulum.bat
  if errorlevel 1 exit /b 1
)

".venv\Scripts\python.exe" baslat.py
if errorlevel 1 (
  echo.
  echo Arsiv Botu beklenmedik sekilde kapandi.
  pause
)
