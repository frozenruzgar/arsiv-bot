"""
Arşiv Botu – Browser Fallback İndirici
=======================================
yt-dlp başarısız olduğunda Chrome üzerinden video indirmeyi dener.

Bu modül bağımsız tutulmuştur; sorun olursa yalnız bu dosyayı düzenlemek yeterlidir.
archive_worker.py hiç değiştirilmeden bu dosyadaki stratejiler güncellenebilir.

Stratejiler (sırayla denenir):
  0. CDP Ağ Dinleme  – Sayfaya giden gerçek HTTP isteklerini yakalar (en güvenilir)
  1. JSON Script     – <script type="application/json"> içinde video_versions aranır
  2. Video Element   – <video> elementinin src/currentSrc özelliği okunur
  3. Performance API – JS performance.getEntriesByType('resource') CDN URL taraması
  4. Window Globals  – window.__additionalData / _sharedData / __initialData taraması
  5. Embed Sayfası   – /reel/{id}/embed/captioned/ farklı sayfa yapısı denenir
  6. Sayfa Etkileşim – Oynat düğmesine tıklanarak video URL yüklenmesi tetiklenir
  7. Script Regex    – Tüm script içeriklerinde CDN .mp4 URL regex taraması

İndirme:
  - Bulunan URL'ler önce doğrulanır (Content-Type, Content-Length)
  - Chunked indirme, 250 MB sınırı
  - MP4 header (ftyp) ve video stream (vide atom) doğrulama
  - Her URL için retry + timeout
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False

from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By

# Instagram medya CDN alan adları
MEDIA_HOST_SUFFIXES = (".cdninstagram.com", ".fbcdn.net")
MAX_DOWNLOAD_BYTES = 250 * 1024 * 1024  # 250 MB
CHUNK_SIZE = 512 * 1024  # 512 KB

# DASH akış segmenti ftyp brandları — bunlar tam MP4 değil, oynatılamaz
_DASH_FTYP_BRANDS = {
    b"iso5", b"iso6", b"iso7", b"iso8", b"iso9",
    b"msdh", b"msix", b"mdsm", b"dash",
    b"isom",  # isom tek başına olabilir ama aşağıda moov ile birlikte kontrol edilir
}


# ---------------------------------------------------------------------------
# Yardımcılar
# ---------------------------------------------------------------------------

def _is_cdn_url(url: str) -> bool:
    """URL'nin Instagram CDN'e ait ve HTTPS olup olmadığını kontrol eder."""
    try:
        parsed = urlsplit(url)
        host = (parsed.hostname or "").lower()
        return (
            parsed.scheme == "https"
            and any(host.endswith(s) for s in MEDIA_HOST_SUFFIXES)
        )
    except Exception:
        return False


def _validate_mp4(path: Path) -> bool:
    """Validate without deleting any user-owned archive file."""
    from media_output import is_valid_mp4
    return is_valid_mp4(path)


def _complete_media_url(url: str) -> str:
    """Browser byte-range queries may contain only MP4 initialization data."""
    from urllib.parse import urlunsplit
    parsed = urlsplit(url)
    query = "&".join(part for part in parsed.query.split("&")
                     if part.split("=", 1)[0].casefold() not in {"bytestart", "byteend"})
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, query, parsed.fragment))


def _add_unique(lst: list[str], url: str) -> None:
    if url and url not in lst:
        lst.append(url)


def _search_dict_for_video(data: object, reel_id: str, out: list[str]) -> None:
    """JSON ağacında reel_id'ye ait video_versions URL'lerini recursive arar."""
    stack = [data]
    while stack:
        value = stack.pop()
        if isinstance(value, dict):
            if value.get("code") == reel_id or value.get("shortcode") == reel_id:
                versions = value.get("video_versions") or value.get("videoVersions") or []
                for v in versions:
                    if isinstance(v, dict):
                        candidate = str(v.get("url") or "")
                        if _is_cdn_url(candidate):
                            _add_unique(out, candidate)
            stack.extend(value.values())
        elif isinstance(value, list):
            stack.extend(value)


# ---------------------------------------------------------------------------
# Strateji 0 – CDP Ağ Dinleme
# ---------------------------------------------------------------------------

def _strategy_cdp_network(driver, reel_id: str) -> list[str]:
    """
    Chrome DevTools Protocol performance log'undan gerçek HTTP isteklerini tarar.
    Sayfanın yüklenmesi sırasında Instagram CDN'e giden video URL'lerini yakalar.
    Bu strateji en güvenilirdir çünkü gerçek ağ trafiğini izler.
    """
    urls: list[str] = []
    try:
        logs = driver.get_log("performance")
        for entry in logs:
            try:
                message = json.loads(entry.get("message", "{}"))
                method = message.get("message", {}).get("method", "")
                if method not in (
                    "Network.responseReceived",
                    "Network.requestWillBeSent",
                    "Network.requestWillBeSentExtraInfo",
                ):
                    continue
                params = message.get("message", {}).get("params", {})
                # responseReceived → response.url
                candidate = str(
                    params.get("response", {}).get("url", "")
                    or params.get("request", {}).get("url", "")
                    or ""
                )
                if (
                    _is_cdn_url(candidate)
                    and ".mp4" in candidate.lower()
                ):
                    _add_unique(urls, candidate)
            except Exception:
                continue
    except Exception:
        pass
    return urls


# ---------------------------------------------------------------------------
# Strateji 1 – JSON Script Ayrıştırma
# ---------------------------------------------------------------------------

def _strategy_json_scripts(driver, reel_id: str) -> list[str]:
    """<script type="application/json"> içinde video_versions aranır."""
    urls: list[str] = []
    try:
        elements = driver.find_elements(By.CSS_SELECTOR, "script[type='application/json']")
        for el in elements:
            try:
                text = el.get_attribute("textContent") or ""
                if not text or len(text) > 4 * 1024 * 1024:
                    continue
                payload = json.loads(text)
                _search_dict_for_video(payload, reel_id, urls)
            except (TypeError, ValueError, WebDriverException):
                continue
    except Exception:
        pass
    return urls


# ---------------------------------------------------------------------------
# Strateji 2 – Video Element
# ---------------------------------------------------------------------------

def _strategy_video_element(driver, reel_id: str) -> list[str]:
    """<video> elementinin src ve currentSrc özelliklerini okur."""
    urls: list[str] = []
    try:
        # Without metadata, never guess between several recommended Reels.
        videos = driver.find_elements(By.CSS_SELECTOR, "video")
        if len(videos) != 1:
            return urls
        for video_el in videos:
            for attr in ("src", "currentSrc"):
                try:
                    src = str(video_el.get_attribute(attr) or "")
                    if src and _is_cdn_url(src):
                        _add_unique(urls, src)
                except WebDriverException:
                    continue
    except Exception:
        pass
    return urls


# ---------------------------------------------------------------------------
# Strateji 3 – Performance API
# ---------------------------------------------------------------------------

def _strategy_performance_api(driver, reel_id: str) -> list[str]:
    """JS performance.getEntriesByType('resource') ile CDN URL'leri tarar."""
    urls: list[str] = []
    try:
        entries = driver.execute_script(
            "try { "
            "  var e = performance.getEntriesByType('resource'), u = []; "
            "  for (var i = 0; i < e.length; i++) { "
            "    var n = e[i].name || ''; "
            "    if ((n.indexOf('cdninstagram.com') !== -1 || n.indexOf('fbcdn.net') !== -1) "
            "        && n.indexOf('.mp4') !== -1) u.push(n); "
            "  } "
            "  return u; "
            "} catch(ex) { return []; }"
        )
        if isinstance(entries, list):
            for candidate in entries:
                candidate = str(candidate)
                if _is_cdn_url(candidate):
                    _add_unique(urls, candidate)
    except Exception:
        pass
    return urls


# ---------------------------------------------------------------------------
# Strateji 4 – Window Globals
# ---------------------------------------------------------------------------

def _strategy_window_globals(driver, reel_id: str) -> list[str]:
    """window.__additionalData / _sharedData / __initialData vb. tarar."""
    urls: list[str] = []
    js_exprs = [
        "return JSON.stringify(window.__additionalData || null)",
        "return JSON.stringify(window._sharedData || null)",
        "return JSON.stringify(window.__initialData || null)",
        "return JSON.stringify(window.__pageData || null)",
        "return JSON.stringify(window.__bbox || null)",
    ]
    for js_expr in js_exprs:
        try:
            raw = driver.execute_script(js_expr)
            if not raw or raw == "null":
                continue
            payload = json.loads(raw)
            _search_dict_for_video(payload, reel_id, urls)
        except Exception:
            continue
    return urls


# ---------------------------------------------------------------------------
# Strateji 5 – Embed Sayfası
# ---------------------------------------------------------------------------

def _strategy_embed_page(driver, reel_id: str, stop_event) -> list[str]:
    """
    /reel/{id}/embed/captioned/ embed sayfasını açar.
    Embed sayfası farklı yapıda olduğu için bazen daha kolay erişilebilir.
    """
    urls: list[str] = []
    embed_url = f"https://www.instagram.com/reel/{reel_id}/embed/captioned/"
    try:
        driver.get(embed_url)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            if stop_event.is_set():
                break
            # Video element dene
            for video_el in driver.find_elements(By.CSS_SELECTOR, "video"):
                for attr in ("src", "currentSrc"):
                    try:
                        src = str(video_el.get_attribute(attr) or "")
                        if src and _is_cdn_url(src):
                            _add_unique(urls, src)
                    except WebDriverException:
                        continue
            if urls:
                break
            # JSON script dene
            extra = _strategy_json_scripts(driver, reel_id)
            urls.extend(u for u in extra if u not in urls)
            if urls:
                break
            stop_event.wait(1)
    except Exception:
        pass
    return urls


# ---------------------------------------------------------------------------
# Strateji 6 – Sayfa Etkileşim
# ---------------------------------------------------------------------------

def _strategy_page_interaction(driver, reel_id: str, stop_event) -> list[str]:
    """
    Oynat düğmesine tıklayarak video URL'sinin tarayıcıya yüklenmesini tetikler.
    Tıklama sonrası CDP log ve video element yeniden taranır.
    """
    urls: list[str] = []
    try:
        videos = driver.find_elements(By.CSS_SELECTOR, "video")
        if len(videos) == 1:
            driver.execute_script("arguments[0].play().catch(function(){});", videos[0])
            stop_event.wait(2)
            urls.extend(_strategy_json_scripts(driver, reel_id))
            urls.extend(_strategy_video_element(driver, reel_id))
    except Exception:
        pass
    return urls


# ---------------------------------------------------------------------------
# Strateji 7 – Script Regex Taraması
# ---------------------------------------------------------------------------

def _strategy_script_regex(driver, reel_id: str) -> list[str]:
    """Tüm <script> içeriklerinde CDN .mp4 URL regex taraması yapar."""
    urls: list[str] = []
    cdn_pat = re.compile(
        r'https://[^\s<>"\']+(?:cdninstagram\.com|fbcdn\.net)[^\s<>"\']*\.mp4[^\s<>"\']*'
    )
    try:
        for script_el in driver.find_elements(By.CSS_SELECTOR, "script"):
            try:
                text = script_el.get_attribute("textContent") or ""
                if not text or len(text) > 4 * 1024 * 1024:
                    continue
                for match in cdn_pat.findall(text):
                    # JSON escape'leri çöz
                    candidate = match.replace("\\u002F", "/").replace("\\/", "/")
                    if _is_cdn_url(candidate):
                        _add_unique(urls, candidate)
            except WebDriverException:
                continue
    except Exception:
        pass
    return urls


# ---------------------------------------------------------------------------
# URL Doğrulama + İndirme
# ---------------------------------------------------------------------------

def _get_headers(driver) -> dict[str, str]:
    """Browser'ın user-agent ve cookie'lerini alır."""
    try:
        user_agent = str(driver.execute_script("return navigator.userAgent") or "Mozilla/5.0")
    except Exception:
        user_agent = "Mozilla/5.0"
    try:
        cookie_header = "; ".join(
            f"{c['name']}={c['value']}"
            for c in driver.get_cookies()
            if "instagram.com" in c.get("domain", "")
        )
    except Exception:
        cookie_header = ""
    headers: dict[str, str] = {
        "User-Agent": user_agent,
        "Referer": "https://www.instagram.com/",
        "Origin": "https://www.instagram.com",
        "Accept": "video/av1,video/mp4,video/*;q=0.9,*/*;q=0.5",
        "Accept-Encoding": "identity",
        "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
        "Sec-Fetch-Mode": "no-cors",
        "Sec-Fetch-Dest": "video",
        "Sec-Fetch-Site": "cross-site",
    }
    if cookie_header:
        headers["Cookie"] = cookie_header
    return headers


def _try_download(url: str, destination: Path, headers: dict[str, str], stop_event) -> bool:
    """
    Tek bir URL'yi indirir. Başarılıysa True döner, değilse False.
    İndirme: chunked, 250 MB sınır, ftyp+vide atom doğrulama.
    """
    destination.unlink(missing_ok=True)
    written = 0
    first_bytes = b""
    try:
        request = Request(_complete_media_url(url), headers=headers)
        with urlopen(request, timeout=120) as response:
            content_range = response.headers.get("Content-Range")
            if content_range:
                match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", content_range)
                if not match or int(match[1]) != 0 or int(match[2]) + 1 != int(match[3]):
                    return False
            # İçerik tipi kontrolü
            content_type = (response.headers.get("Content-Type") or "").lower()
            if "text/html" in content_type or "application/json" in content_type:
                return False
            # Boyut ön kontrolü
            declared = response.headers.get("Content-Length")
            expected = int(declared) if declared and declared.isdigit() else None
            if declared:
                try:
                    if int(declared) > MAX_DOWNLOAD_BYTES:
                        return False
                except ValueError:
                    pass
            with destination.open("wb") as output:
                while True:
                    if stop_event.is_set():
                        raise RuntimeError("İndirme durduruldu.")
                    chunk = response.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    if not first_bytes:
                        first_bytes = chunk[:64]
                    written += len(chunk)
                    if written > MAX_DOWNLOAD_BYTES:
                        raise RuntimeError("İndirme boyut sınırını aştı.")
                    output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        return False

    if written <= 0 or (expected is not None and written != expected):
        destination.unlink(missing_ok=True)
        return False

    # MP4 doğrulama: ftyp + moov + vide atom
    if not _validate_mp4(destination):
        return False

    return True


# ---------------------------------------------------------------------------
# Tarama Sırasında CDN URL Toplama (Chrome'u hareket ettirmeden)
# ---------------------------------------------------------------------------

def collect_cdn_urls_from_log(driver) -> list[str]:
    """
    Şu anda Chrome'un belleğindeki performance logunu tarar ve
    Instagram CDN'e ait tüm .mp4 URL'lerini döndürür.
    Driver herhangi bir sayfada olabilir; sayfayı hareket ettirmez.
    Bu fonksiyon tarama aşamasında her item için çağrılır.
    """
    urls: list[str] = []
    try:
        logs = driver.get_log("performance")
        for entry in logs:
            try:
                message = json.loads(entry.get("message", "{}"))
                method = message.get("message", {}).get("method", "")
                if method not in (
                    "Network.responseReceived",
                    "Network.requestWillBeSent",
                    "Network.requestWillBeSentExtraInfo",
                ):
                    continue
                params = message.get("message", {}).get("params", {})
                candidate = str(
                    params.get("response", {}).get("url", "")
                    or params.get("request", {}).get("url", "")
                    or ""
                )
                if (
                    _is_cdn_url(candidate)
                    and ".mp4" in candidate.lower()
                ):
                    _add_unique(urls, candidate)
            except Exception:
                continue
    except Exception:
        pass
    return urls


# ---------------------------------------------------------------------------
# Chrome'u Bypass Eden Python requests İndirici
# ---------------------------------------------------------------------------

def download_via_requests(
    cdn_urls: list[str],
    destination: Path,
    driver,
    stop_event,
    log_fn=None,
) -> bool:
    """
    Verilen CDN URL listesini Python requests kütüphanesiyle indirir.
    Chrome'a bağlanmaz; requests doğrudan CDN'e gider.
    Başarılıysa True, hiçbirinde başarılı olunmazsa False döner.

    Args:
        cdn_urls:    Denenecek CDN .mp4 URL'leri (cdninstagram.com / fbcdn.net)
        destination: MP4 yazılacak tam yol
        driver:      Cookie ve user-agent almak için kullanılır (indirme yapmaz)
        stop_event:  threading.Event
        log_fn:      İsteğe bağlı log fonksiyonu
    """
    if not cdn_urls:
        return False
    if not _HAS_REQUESTS:
        if log_fn:
            log_fn("[requests indirici] 'requests' kütüphanesi yüklü değil; atlanıyor.")
        return False

    headers = _get_headers(driver)
    # requests için Cookie header'ı ayrı session cookie'ye çevir
    session_cookies: dict[str, str] = {}
    try:
        for c in driver.get_cookies():
            if "instagram.com" in c.get("domain", ""):
                session_cookies[c["name"]] = c["value"]
    except Exception:
        pass

    for i, url in enumerate(cdn_urls[:10], 1):
        if stop_event.is_set():
            return False
        if log_fn:
            log_fn(f"[requests indirici] CDN URL {i}/{min(len(cdn_urls), 10)} deneniyor...")
        destination.unlink(missing_ok=True)
        written = 0
        first_bytes = b""
        try:
            with _requests.get(
                _complete_media_url(url),
                headers={
                    **headers,
                    # requests kendi Cookie header'ını cookies= üzerinden yönetir
                },
                cookies=session_cookies,
                stream=True,
                timeout=(15, 120),
                allow_redirects=True,
            ) as resp:
                content_type = (resp.headers.get("Content-Type") or "").lower()
                if resp.status_code not in (200, 206):
                    continue
                content_range = resp.headers.get("Content-Range")
                if content_range:
                    match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", content_range)
                    if not match or int(match[1]) != 0 or int(match[2]) + 1 != int(match[3]):
                        continue
                if "text/html" in content_type or "application/json" in content_type:
                    continue
                declared = resp.headers.get("Content-Length")
                expected = int(declared) if declared and declared.isdigit() else None
                if declared:
                    try:
                        if int(declared) > MAX_DOWNLOAD_BYTES:
                            continue
                    except ValueError:
                        pass
                with destination.open("wb") as output:
                    for chunk in resp.iter_content(chunk_size=CHUNK_SIZE):
                        if stop_event.is_set():
                            raise RuntimeError("İndirme durduruldu.")
                        if chunk:
                            if not first_bytes:
                                first_bytes = chunk[:64]
                            written += len(chunk)
                            if written > MAX_DOWNLOAD_BYTES:
                                raise RuntimeError("İndirme boyut sınırını aştı.")
                            output.write(chunk)
        except Exception:
            destination.unlink(missing_ok=True)
            continue

        if written <= 0 or (expected is not None and written != expected):
            destination.unlink(missing_ok=True)
            continue
        # MP4 doğrulama: ftyp + moov + vide atom
        if not _validate_mp4(destination):
            if log_fn:
                log_fn(f"[requests indirici] URL {i}: DASH segment veya bozuk dosya, atlanıyor.")
            continue
        if log_fn:
            log_fn(f"[requests indirici] İndirme başarılı ({written // 1024} KB).")
        return True

    return False


# ---------------------------------------------------------------------------
# Ana Giriş Noktası
# ---------------------------------------------------------------------------

def download_reel_via_browser(
    driver,
    item: dict,
    destination: Path,
    stop_event,
    log_fn=None,
) -> None:
    """
    yt-dlp başarısız olduğunda çağrılır.
    Sırasıyla tüm stratejileri dener, başarılıysa döner.
    Hiçbiri başarılı olmazsa RuntimeError fırlatır.

    Args:
        driver:      Selenium WebDriver (Instagram'a giriş yapılmış)
        item:        {"id": reel_id, "url": reel_url, ...}
        destination: MP4 dosyasının yazılacağı tam yol
        stop_event:  threading.Event – set() edilirse indirme iptal edilir
        log_fn:      İsteğe bağlı logging fonksiyonu (str → None)
    """
    reel_id = str(item.get("id") or "")
    reel_url = str(item.get("url") or f"https://www.instagram.com/reel/{reel_id}/")

    def log(msg: str) -> None:
        if log_fn:
            log_fn(msg)

    collected: list[str] = []

    # Drain profile-scan logs; they contain other Reel resources.
    try:
        driver.get_log("performance")
    except Exception:
        pass
    # --- Reel sayfasını aç ---
    log(f"[Browser Fallback] {reel_id} için Reel sayfası açılıyor...")
    try:
        driver.get(reel_url)
    except Exception:
        pass  # Zaman aşımı olsa bile DOM yüklü olabilir

    # Sayfanın kısmen yüklenmesi için kısa bekleme
    stop_event.wait(3)
    if stop_event.is_set():
        raise RuntimeError("İndirme durduruldu.")

    # Giriş/doğrulama sayfasına yönlendirme kontrolü
    try:
        current_url = str(getattr(driver, "current_url", "") or "").lower()
        if any(part in current_url for part in ("/accounts/login", "/challenge", "/checkpoint")):
            raise RuntimeError(
                f"Reel {reel_id}: Instagram oturumu yeniden giriş istiyor."
            )
    except RuntimeError:
        raise
    except Exception:
        pass

    # --- Strateji 1: JSON Script ---
    log(f"[Browser Fallback] {reel_id} Strateji 1: JSON script taraması...")
    for url in _strategy_json_scripts(driver, reel_id):
        _add_unique(collected, url)

    # --- Strateji 4: Window Globals ---
    log(f"[Browser Fallback] {reel_id} Strateji 4: Window globals...")
    for url in _strategy_window_globals(driver, reel_id):
        _add_unique(collected, url)

    if not collected:
        # On the individual Reel page, currentSrc is safer than a grid-wide
        # performance/CDN list (which can belong to recommendations).
        for url in _strategy_video_element(driver, reel_id):
            _add_unique(collected, url)

    # Eğer henüz URL bulunamadıysa daha ağır stratejilere geç
    if not collected:
        # --- Strateji 5: Embed Sayfası ---
        log(f"[Browser Fallback] {reel_id} Strateji 5: Embed sayfası deneniyor...")
        for url in _strategy_embed_page(driver, reel_id, stop_event):
            _add_unique(collected, url)

        if stop_event.is_set():
            raise RuntimeError("İndirme durduruldu.")

        # Reel sayfasına geri dön (embed sonrası)
        if not collected:
            try:
                driver.get(reel_url)
                stop_event.wait(3)
            except Exception:
                pass

        # --- Strateji 6: Sayfa Etkileşim ---
        log(f"[Browser Fallback] {reel_id} Strateji 6: Sayfa etkileşimi...")
        for url in _strategy_page_interaction(driver, reel_id, stop_event):
            _add_unique(collected, url)

        if stop_event.is_set():
            raise RuntimeError("İndirme durduruldu.")

    if not collected:
        raise RuntimeError(
            f"Reel {reel_id}: Browser fallback hiçbir video URL bulamadı."
        )

    log(f"[Browser Fallback] {reel_id}: {len(collected)} URL bulundu, indirme başlıyor...")

    # --- İndirme ---
    headers = _get_headers(driver)
    for i, url in enumerate(collected[:10], 1):  # En fazla 10 URL dene
        if stop_event.is_set():
            raise RuntimeError("İndirme durduruldu.")
        log(f"[Browser Fallback] {reel_id}: URL {i}/{min(len(collected), 10)} deneniyor...")
        if _try_download(url, destination, headers, stop_event):
            from media_output import is_valid_mp4, prepare_mp4
            try:
                if not is_valid_mp4(destination, require_audio=item.get("has_audio") is not False):
                    continue
                prepare_mp4(destination, stop_event, require_audio=item.get("has_audio") is not False)
            except Exception:
                if stop_event.is_set():
                    raise
                continue
            log(f"[Browser Fallback] {reel_id}: İndirme başarılı.")
            return

    raise RuntimeError(
        f"Reel {reel_id}: Browser fallback {min(len(collected), 10)} URL denedi, "
        "hiçbirinden geçerli MP4 oluşturulamadı."
    )
