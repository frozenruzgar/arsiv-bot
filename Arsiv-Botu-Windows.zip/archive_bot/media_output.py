"""Archive media assembly: local FFmpeg, playable H.264/AAC, atomic output."""
from __future__ import annotations

import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time

from source_copy import SourceCancelled, SourceUnavailable

MAX_BYTES = 250 * 1024 * 1024


def find_ffmpeg(app_root: Path | None = None) -> str:
    executable = shutil.which("ffmpeg")
    if executable:
        return executable
    root = app_root or Path(__file__).resolve().parent.parent
    folders = [
        root / ".runtime" / "Lib" / "site-packages" / "imageio_ffmpeg" / "binaries",
        root / "ffmpeg" / "bin",
    ]
    for folder in folders:
        for candidate in sorted(folder.glob("ffmpeg*.exe")):
            if candidate.is_file():
                return str(candidate)
    try:
        import imageio_ffmpeg
        candidate = imageio_ffmpeg.get_ffmpeg_exe()
        if Path(candidate).is_file():
            return candidate
    except (ImportError, RuntimeError):
        pass
    raise SourceUnavailable("Ses ve görüntüyü birleştirmek için yerel FFmpeg bulunamadı.")


def _run_ffmpeg(executable: str, arguments: list[str], stop: threading.Event, timeout: int = 300):
    if stop.is_set():
        raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
    process = subprocess.Popen(
        [executable, "-hide_banner", "-nostdin", *arguments],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    deadline = time.monotonic() + timeout
    try:
        while True:
            if stop.is_set():
                raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
            if time.monotonic() >= deadline:
                raise SourceUnavailable("Ses/görüntü hazırlama süre sınırına ulaştı.")
            try:
                stdout, stderr = process.communicate(timeout=0.25)
                return process.returncode, stdout, stderr
            except subprocess.TimeoutExpired:
                continue
    finally:
        if process.poll() is None:
            process.kill()
            process.communicate()


def mp4_tracks(path: Path) -> set[str]:
    """Read real ISO-BMFF boxes; never delete or modify an existing archive file."""
    tracks: set[str] = set()
    has_ftyp = has_moov = has_mdat = False
    containers = {b"moov", b"trak", b"mdia", b"minf", b"stbl", b"dinf", b"edts", b"mvex", b"moof", b"traf"}
    try:
        size = path.stat().st_size
        if not 32 <= size <= MAX_BYTES:
            return set()
        with path.open("rb") as stream:
            def walk(start: int, end: int, depth: int = 0) -> bool:
                nonlocal has_ftyp, has_moov, has_mdat
                position = start
                while position < end:
                    if end - position < 8:
                        return False
                    stream.seek(position)
                    header = stream.read(8)
                    length, kind = int.from_bytes(header[:4], "big"), header[4:]
                    header_size = 8
                    if length == 1:
                        if end - position < 16:
                            return False
                        length = int.from_bytes(stream.read(8), "big")
                        header_size = 16
                    elif length == 0:
                        length = end - position
                    if length < header_size or position + length > end:
                        return False
                    payload, finish = position + header_size, position + length
                    if depth == 0:
                        has_ftyp |= kind == b"ftyp"
                        has_moov |= kind == b"moov"
                        has_mdat |= kind == b"mdat" and finish > payload
                    if kind == b"hdlr" and finish - payload >= 12:
                        stream.seek(payload + 8)
                        handler = stream.read(4)
                        if handler in (b"vide", b"soun"):
                            tracks.add(handler.decode("ascii"))
                    if kind in containers:
                        if depth >= 8 or not walk(payload, finish, depth + 1):
                            return False
                    position = finish
                return position == end

            if not walk(0, size) or not (has_ftyp and has_moov and has_mdat):
                return set()
    except (OSError, ValueError):
        return set()
    return tracks


def is_valid_mp4(path: Path, require_audio: bool = False) -> bool:
    tracks = mp4_tracks(path)
    return "vide" in tracks and (not require_audio or "soun" in tracks)


def inspect_media(path: Path, executable: str, stop: threading.Event, full: bool = False) -> dict:
    args = ["-v", "info", "-xerror", "-err_detect", "explode", "-i", str(path),
            "-map", "0:v:0", "-map", "0:a:0?"]
    if not full:
        args += ["-t", "0.15"]
    args += ["-progress", "pipe:1", "-nostats", "-f", "null", "-"]
    code, progress, diagnostic = _run_ffmpeg(executable, args, stop)
    frames = [int(value) for value in re.findall(r"^frame=(\d+)\s*$", progress, re.MULTILINE)]
    if code or not frames or max(frames) < 1:
        raise SourceUnavailable("Video akışı tam olarak çözülemedi; indirme yeniden denenmeli.")
    # Only the input section: the null-output encoder has different codecs.
    input_section = diagnostic.split("Stream mapping:", 1)[0]
    video = re.search(r"Video:\s*([^\s,]+)", input_section)
    audio = re.search(r"Audio:\s*([^\s,]+)", input_section)
    return {"video_codec": video.group(1) if video else "", "audio_codec": audio.group(1) if audio else ""}


def prepare_mp4(path: Path, stop: threading.Event, *, executable: str | None = None,
                require_audio: bool = True) -> None:
    """Remux supported video, convert other codecs, preserve/encode audio, verify frames."""
    executable = executable or find_ffmpeg()
    # The merger may legitimately return MKV/WebM; FFmpeg probes the actual
    # container, not the temporary filename. Validate the final MP4 afterwards.
    if not 0 < path.stat().st_size <= MAX_BYTES:
        raise SourceUnavailable("Tam ses/görüntü akışı alınamadı; aynı Reel yeniden denenmeli.")
    media = inspect_media(path, executable, stop)
    if require_audio and not media["audio_codec"]:
        raise SourceUnavailable("Reel'in ses akışı henüz birleştirilmedi.")
    ready = path.with_name(path.name + ".ready.mp4")
    args = ["-y", "-v", "error", "-xerror", "-i", str(path), "-map", "0:v:0", "-map", "0:a:0?",
            "-map_metadata", "-1"]
    if media["video_codec"] == "h264":
        args += ["-c:v", "copy", "-tag:v", "avc1"]
    else:
        args += ["-c:v", "libx264", "-preset", "fast", "-crf", "20", "-pix_fmt", "yuv420p",
                 "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-tag:v", "avc1"]
    args += ["-c:a", "copy" if media["audio_codec"] == "aac" else "aac", "-movflags", "+faststart",
             "-f", "mp4", str(ready)]
    try:
        code, _, _ = _run_ffmpeg(executable, args, stop)
        if code or not is_valid_mp4(ready, require_audio):
            raise SourceUnavailable("Reel ses/görüntü birleştirmesi tamamlanamadı.")
        verified = inspect_media(ready, executable, stop, full=True)
        if verified["video_codec"] != "h264" or (require_audio and verified["audio_codec"] != "aac"):
            raise SourceUnavailable("Reel oynatıcıya uyumlu biçimde hazırlanamadı.")
        os.replace(ready, path)
    finally:
        ready.unlink(missing_ok=True)


def commit_mp4(partial: Path, target: Path) -> None:
    """Keep an old unplayable output recoverable until its replacement is ready."""
    backup = None
    if target.exists():
        folder = target.parent / ".arsiv-botu" / "previous-files"
        folder.mkdir(parents=True, exist_ok=True)
        backup = folder / f"{target.stem}-{time.time_ns()}.mp4"
        os.replace(target, backup)
    try:
        os.replace(partial, target)
    except OSError:
        if backup is not None and not target.exists():
            os.replace(backup, target)
        raise
