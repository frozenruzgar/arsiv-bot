from __future__ import annotations

import json
import os
import secrets
import shutil
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from archive_worker import (
    ArchiveDownloadWorker,
    account_root,
    safe_username,
    saved_instagram_sessions,
    validate_download_request,
)


HOST = "127.0.0.1"
PORT = int(os.environ.get("ARCHIVE_BOT_PORT", "5090"))
ROOT = Path(__file__).resolve().parent
TEMPLATE = ROOT / "templates" / "index.html"
FOLDER_LOCK = threading.RLock()
SELECTED_FOLDERS: dict[str, tuple[str, Path]] = {}
EVENT_LOCK = threading.RLock()
WORKER_LOCK = threading.RLock()
WORKERS: dict[str, ArchiveDownloadWorker] = {}
LATEST_STATES: dict[str, dict[str, object]] = {}
CURRENT_SERVER: ThreadingHTTPServer | None = None
BLANK_STATE_TEMPLATE = ArchiveDownloadWorker(lambda _state: None).snapshot()


def _blank_state(account: str = "") -> dict[str, object]:
    state = dict(BLANK_STATE_TEMPLATE)
    state["workspaceAccount"] = account
    if account:
        state["sessionAccount"] = account
    return state


def optional_username(value: object) -> str:
    raw = str(value or "").strip()
    return safe_username(raw) if raw else ""


def _state_callback(account: str):
    def changed(state: dict[str, object]) -> None:
        snapshot = dict(state)
        snapshot["workspaceAccount"] = account
        with EVENT_LOCK:
            LATEST_STATES[account] = snapshot

    return changed


def worker_for(account: object, *, create: bool = True) -> ArchiveDownloadWorker | None:
    username = optional_username(account)
    if not username:
        return None
    with WORKER_LOCK:
        worker = WORKERS.get(username)
        if worker is None and create:
            worker = ArchiveDownloadWorker(_state_callback(username))
            WORKERS[username] = worker
            _state_callback(username)(worker.snapshot())
        return worker


def snapshot_for(account: object) -> dict[str, object]:
    username = optional_username(account)
    if not username:
        return _blank_state()
    worker = worker_for(username)
    if worker is None:
        return _blank_state(username)
    state = worker.snapshot()
    state["workspaceAccount"] = username
    if not state.get("sessionAccount"):
        state["sessionAccount"] = username
    return state


def account_summaries() -> list[dict[str, object]]:
    sessions = set(saved_instagram_sessions())
    with WORKER_LOCK:
        names = sessions | set(WORKERS)
        workers = {name: WORKERS.get(name) for name in names}

    summaries: list[dict[str, object]] = []
    for username in names:
        worker = workers.get(username)
        state = worker.snapshot() if worker is not None else _blank_state(username)
        state["workspaceAccount"] = username
        if not state.get("sessionAccount"):
            state["sessionAccount"] = username
        summaries.append({
            "username": username,
            "saved": username in sessions,
            "state": state,
        })
    summaries.sort(
        key=lambda item: (
            not bool(item["state"].get("running")),
            not bool(item["state"].get("loginRunning")),
            str(item["username"]).casefold(),
        )
    )
    return summaries


def any_worker_active() -> bool:
    with WORKER_LOCK:
        workers = list(WORKERS.values())
    for worker in workers:
        state = worker.snapshot()
        if state.get("running") or state.get("loginRunning"):
            return True
    return False


def choose_windows_folder() -> Path | None:
    if os.name != "nt":
        return None

    # Yöntem 1: Shell.Application COM nesnesi
    script_com = (
        "$shell = New-Object -ComObject Shell.Application; "
        "$folder = $shell.BrowseForFolder(0, 'Videoların indirileceği klasörü seçin', 0, 17); "
        "if ($folder) { "
        "[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new(); "
        "Write-Output $folder.Self.Path }"
    )
    try:
        completed = subprocess.run(
            ["powershell.exe", "-NoProfile", "-STA", "-Command", script_com],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=0,
            timeout=600,
            check=False,
        )
        selected = completed.stdout.strip()
        if completed.returncode == 0 and selected:
            path = Path(selected).resolve()
            if path.is_dir():
                return path
        if completed.returncode == 0 and not selected:
            return None
    except (OSError, subprocess.SubprocessError, subprocess.TimeoutExpired):
        pass

    # Yöntem 2: Windows Forms FolderBrowserDialog (yedek)
    script_wf = (
        "Add-Type -AssemblyName System.Windows.Forms; "
        "$owner = New-Object System.Windows.Forms.Form; "
        "$owner.StartPosition = 'CenterScreen'; "
        "$owner.Size = New-Object System.Drawing.Size(1,1); "
        "$owner.ShowInTaskbar = $false; "
        "$owner.TopMost = $true; "
        "$owner.Opacity = 0; "
        "$owner.Show(); "
        "$dialog = New-Object System.Windows.Forms.FolderBrowserDialog; "
        "$dialog.Description = 'Videoların indirileceği klasörü seçin'; "
        "$dialog.ShowNewFolderButton = $true; "
        "$result = $dialog.ShowDialog($owner); $owner.Close(); "
        "if ($result -eq [System.Windows.Forms.DialogResult]::OK) { "
        "[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new(); "
        "Write-Output $dialog.SelectedPath }"
    )
    try:
        completed = subprocess.run(
            ["powershell.exe", "-NoProfile", "-STA", "-Command", script_wf],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=0,
            timeout=600,
            check=False,
        )
        selected = completed.stdout.strip()
        if completed.returncode != 0:
            raise RuntimeError("Windows klasör seçme penceresi açılamadı.")
        if not selected:
            return None
        path = Path(selected).resolve()
        if not path.is_dir():
            raise RuntimeError("Seçilen klasör bulunamadı.")
        return path
    except (OSError, subprocess.SubprocessError) as error:
        raise RuntimeError(f"Klasör seçme penceresi açılamadı: {error}") from error


class ArchiveHandler(BaseHTTPRequestHandler):
    server_version = "ArsivBotu/2.0"
    sys_version = ""

    def log_message(self, format: str, *args: object) -> None:
        return

    def send_bytes(self, content: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)

    def send_json(self, payload: object, status: int = 200) -> None:
        self.send_bytes(
            json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            "application/json; charset=utf-8",
            status,
        )

    def read_json(self) -> dict[str, object]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return {}
        if length <= 0 or length > 32 * 1024:
            return {}
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}
        return value if isinstance(value, dict) else {}

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        account = optional_username((query.get("account") or [""])[0])
        if path in {"", "/"}:
            if not TEMPLATE.is_file():
                self.send_bytes(b"Template missing", "text/plain; charset=utf-8", 500)
                return
            self.send_bytes(TEMPLATE.read_bytes(), "text/html; charset=utf-8")
            return
        if path == "/api/status":
            self.send_json({
                "ok": True,
                "state": snapshot_for(account),
                "sessions": saved_instagram_sessions(),
                "accounts": account_summaries(),
            })
            return
        if path == "/api/screenshot":
            worker = worker_for(account, create=False)
            image = worker.screenshot_bytes() if worker is not None else None
            if not image:
                self.send_bytes(b"", "image/png", 204)
                return
            self.send_bytes(image, "image/png")
            return
        self.send_json({"ok": False, "message": "Sayfa bulunamadı."}, 404)

    def do_POST(self) -> None:
        path = urlparse(self.path).path

        if path == "/api/folder/select":
            payload = self.read_json()
            account = optional_username(payload.get("account"))
            worker = worker_for(account, create=False)
            if worker is not None and worker.snapshot().get("running"):
                self.send_json({"ok": False, "message": "İndirme çalışırken hedef klasör değiştirilemez."}, 409)
                return
            try:
                folder = choose_windows_folder()
            except (OSError, RuntimeError, subprocess.SubprocessError) as error:
                self.send_json({"ok": False, "message": str(error)}, 500)
                return
            if folder is None:
                self.send_json({"ok": True, "cancelled": True})
                return
            token = secrets.token_urlsafe(24)
            with FOLDER_LOCK:
                SELECTED_FOLDERS[token] = (account, folder)
            self.send_json({"ok": True, "cancelled": False, "folderToken": token, "folder": str(folder)})
            return

        if path == "/api/folder/path":
            payload = self.read_json()
            account = optional_username(payload.get("account"))
            worker = worker_for(account, create=False)
            if worker is not None and worker.snapshot().get("running"):
                self.send_json({"ok": False, "message": "İndirme çalışırken hedef klasör değiştirilemez."}, 409)
                return
            raw_folder = str(payload.get("folder") or "").strip().strip('"')
            folder = Path(os.path.expandvars(raw_folder)).expanduser().resolve()
            if not raw_folder or not folder.is_dir():
                self.send_json({"ok": False, "message": "Geçerli bir hedef klasör yolu girin."}, 400)
                return
            token = secrets.token_urlsafe(24)
            with FOLDER_LOCK:
                SELECTED_FOLDERS[token] = (account, folder)
            self.send_json({"ok": True, "cancelled": False, "folderToken": token, "folder": str(folder)})
            return

        if path == "/api/login/start":
            payload = self.read_json()
            account = optional_username(payload.get("username"))
            worker = worker_for(account)
            if worker is None:
                self.send_json({"ok": False, "message": "Instagram kullanıcı adını yazın."}, 400)
                return
            try:
                worker.start_login(account)
            except (OSError, ValueError) as error:
                self.send_json({"ok": False, "message": str(error)}, 400)
                return
            self.send_json({
                "ok": True,
                "message": "Arşiv Botu için ayrı, görünür Chrome giriş penceresi açılıyor.",
                "state": snapshot_for(account),
            }, 202)
            return

        if path == "/api/login/stop":
            payload = self.read_json()
            account = optional_username(payload.get("account") or payload.get("username"))
            worker = worker_for(account, create=False)
            if worker is None:
                self.send_json({"ok": False, "message": "Hesap çalışma alanı bulunamadı."}, 404)
                return
            if worker.snapshot().get("running"):
                self.send_json({"ok": False, "message": "İndirme çalışırken Chrome kapatılamaz."}, 409)
                return
            worker.stop_login()
            self.send_json({"ok": True, "message": "Arşiv Botu giriş Chrome'u kapatıldı."})
            return

        if path == "/api/session/delete":
            payload = self.read_json()
            account = optional_username(payload.get("account"))
            confirmed_account = optional_username(payload.get("confirmAccount"))
            if not account or confirmed_account != account:
                self.send_json({"ok": False, "message": "Silinecek hesabı doğrulayın."}, 400)
                return

            worker = worker_for(account, create=False)
            if worker is not None:
                state = worker.snapshot()
                if state.get("running"):
                    self.send_json({
                        "ok": False,
                        "message": "Bu hesapta indirme çalışıyor. Önce işi durdurun, sonra oturumu silin.",
                    }, 409)
                    return
                if state.get("loginRunning"):
                    self.send_json({
                        "ok": False,
                        "message": "Bu hesabın giriş penceresi açık. Önce Chrome'u kapatın, sonra oturumu silin.",
                    }, 409)
                    return
                # Giriş tamamlandıktan sonra açık kalmış olabilecek yalnızca bu
                # hesaba ait Chrome'u kapat; diğer hesapların işlerine dokunma.
                worker.stop_login()

            session_root = account_root(account)
            try:
                if session_root.exists():
                    shutil.rmtree(session_root)
            except OSError as error:
                self.send_json({
                    "ok": False,
                    "message": f"Oturum dosyaları silinemedi: {error}",
                }, 500)
                return

            with WORKER_LOCK:
                WORKERS.pop(account, None)
            with EVENT_LOCK:
                LATEST_STATES.pop(account, None)
            with FOLDER_LOCK:
                stale_tokens = [
                    token for token, (folder_account, _folder) in SELECTED_FOLDERS.items()
                    if folder_account == account
                ]
                for token in stale_tokens:
                    SELECTED_FOLDERS.pop(token, None)

            self.send_json({
                "ok": True,
                "message": f"@{account} oturumu silindi. İndirilen MP4 dosyalarına dokunulmadı.",
                "account": account,
            })
            return

        if path == "/api/download/start":
            payload = self.read_json()
            token = str(payload.get("folderToken") or "")
            with FOLDER_LOCK:
                selection = SELECTED_FOLDERS.get(token)
            if selection is None:
                self.send_json({"ok": False, "message": "Önce hedef klasörü seçin."}, 400)
                return
            folder_account, folder = selection
            try:
                profile, count, session, pacing_mode = validate_download_request(
                    payload.get("sourceProfile"),
                    payload.get("count"),
                    payload.get("sessionAccount"),
                    payload.get("pacingMode"),
                )
                if folder_account and folder_account != session:
                    raise ValueError("Hedef klasörü bu hesap çalışma alanında yeniden seçin.")
                worker = worker_for(session)
                if worker is None:
                    raise ValueError("Instagram hesabı seçilmedi.")
                worker.start(profile, count, session, folder, pacing_mode)
            except (OSError, ValueError) as error:
                self.send_json({"ok": False, "message": str(error)}, 400)
                return
            self.send_json({"ok": True, "message": "Profil taraması ve indirme başlatıldı.", "state": snapshot_for(session)})
            return

        if path == "/api/download/stop":
            payload = self.read_json()
            account = optional_username(payload.get("account") or payload.get("sessionAccount"))
            worker = worker_for(account, create=False)
            if worker is None or not worker.snapshot().get("running"):
                self.send_json({"ok": False, "message": "Çalışan indirme yok."}, 409)
                return
            worker.stop()
            self.send_json({"ok": True, "message": "Durdurma istendi; indirilen dosyalar silinmeyecek."})
            return

        if path == "/api/browser/toggle":
            payload = self.read_json()
            account = optional_username(payload.get("account") or payload.get("sessionAccount"))
            worker = worker_for(account, create=False)
            if worker is None:
                self.send_json({"ok": False, "message": "Hesap çalışma alanı bulunamadı."}, 404)
                return
            try:
                visible = worker.toggle_browser_visibility()
            except ValueError as error:
                self.send_json({"ok": False, "message": str(error)}, 409)
                return
            message = (
                "Chrome görünür yapıldı; tarama duraklatıldı. Reel listesini elle aşağı kaydırın; "
                "bitince aynı düğmeye basıp devam edin."
                if visible
                else "Chrome ekran dışına alındı; tarama kaldığı yerden devam ediyor."
            )
            self.send_json({"ok": True, "visible": visible, "message": message, "state": snapshot_for(account)})
            return

        if path == "/api/server/stop":
            if any_worker_active():
                self.send_json({"ok": False, "message": "Önce tüm hesapların işlerini durdurun, ardından sunucuyu kapatın."}, 409)
                return
            self.send_json({"ok": True, "message": "Sunucu kapatılıyor…"})
            def _shutdown():
                import time as _time
                _time.sleep(0.3)
                if CURRENT_SERVER is not None:
                    CURRENT_SERVER.shutdown()
            threading.Thread(target=_shutdown, daemon=True, name="server-shutdown").start()
            return

        self.send_json({"ok": False, "message": "Geçersiz istek."}, 404)


def main() -> None:
    global CURRENT_SERVER
    server = ThreadingHTTPServer((HOST, PORT), ArchiveHandler)
    CURRENT_SERVER = server
    print(f"Arşiv Botu: http://{HOST}:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        CURRENT_SERVER = None
        with WORKER_LOCK:
            workers = list(WORKERS.values())
        for worker in workers:
            state = worker.snapshot()
            if state.get("running"):
                worker.stop()
            if state.get("loginRunning"):
                worker.stop_login()
        server.server_close()


if __name__ == "__main__":
    main()
