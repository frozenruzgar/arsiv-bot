from __future__ import annotations

import json
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable


ROOT = Path(__file__).resolve().parent
APP_ROOT = ROOT.parent
INSTAGRAM_POST_ROOT = APP_ROOT / "instagram_post"
if str(INSTAGRAM_POST_ROOT) not in sys.path:
    sys.path.insert(0, str(INSTAGRAM_POST_ROOT))
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from source_copy import (  # noqa: E402
    InstagramSourceCopy,
    SourceCancelled,
    SourceCopyError,
    SourceUnavailable,
    _profile,
)
from browser_downloader import download_reel_via_browser  # noqa: E402
from rescan_cycle import ArchiveRescanCycle  # noqa: E402
from media_output import (  # noqa: E402
    commit_mp4, find_ffmpeg, is_valid_mp4 as _validate_mp4, prepare_mp4,
)

import undetected_chromedriver as uc  # noqa: E402

from chrome_compat import explain_chrome_start_error, safe_quit_undetected, start_undetected_chrome  # noqa: E402
from selenium.common.exceptions import TimeoutException, WebDriverException  # noqa: E402
from selenium.webdriver.common.by import By  # noqa: E402
from selenium.webdriver.support import expected_conditions as EC  # noqa: E402
from selenium.webdriver.support.ui import WebDriverWait  # noqa: E402


ARCHIVE_HISTORY_DIR = ".arsiv-botu"
VIDEO_PATTERN = re.compile(r"^(?P<id>[A-Za-z0-9_-]{1,64})\.mp4$", re.IGNORECASE)
PACING_PRESETS = {
    "fast":   {"label": "Hızlı",   "delay": (3, 7),   "batch": 100, "break": (120, 240)},
    "normal": {"label": "Normal",  "delay": (12, 17), "batch": 50,  "break": (300, 600)},
    "safe":   {"label": "Güvenli", "delay": (20, 35), "batch": 25,  "break": (600, 900)},
}


def safe_username(value: object) -> str:
    username = re.sub(r"[^A-Za-z0-9._-]", "", str(value or "").strip().lstrip("@"))
    if (
        not username
        or username in {".", ".."}
        or ".." in username
        or username.startswith(".")
        or username.endswith(".")
        or len(username) > 64
    ):
        raise ValueError("Geçerli bir Instagram kullanıcı adı gerekli.")
    return username


def application_data_root() -> Path:
    """Arşiv Botu'na ait, diğer botlardan tamamen ayrı oturum alanı."""
    override = os.environ.get("INSTAGRAM_ARCHIVE_DATA_ROOT")
    if override:
        return Path(override).expanduser().resolve()
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home())
    return base / "InstagramArchiveBot"


def account_root(username: str) -> Path:
    return application_data_root() / "accounts" / safe_username(username)


def has_saved_session(username: str) -> bool:
    root = account_root(username)
    profile = root / "chrome-profile" / "Default"
    return any(path.is_file() for path in (
        root / ".session_valid", profile / "Network" / "Cookies", profile / "Cookies",
    ))


def saved_instagram_sessions() -> list[str]:
    accounts = application_data_root() / "accounts"
    if not accounts.is_dir():
        return []
    result = []
    for path in accounts.iterdir():
        if not path.is_dir():
            continue
        try:
            username = safe_username(path.name)
        except ValueError:
            continue
        if has_saved_session(username):
            result.append(username)
    return sorted(result, key=str.casefold)


def validate_download_request(
    source_profile: object, count: object, session_account: object, pacing_mode: object = "normal"
) -> tuple[str, int, str, str]:
    profile = _profile(str(source_profile or ""))
    if not profile:
        raise ValueError("İndirilecek Instagram kullanıcı adını girin.")
    if isinstance(count, bool) or not re.fullmatch(r"\d+", str(count).strip()):
        raise ValueError("Video sayısı rakam olmalı.")
    limit = int(str(count).strip())
    if limit < 1:
        raise ValueError("Video sayısı en az 1 olmalı.")
    login = safe_username(session_account)
    if login not in saved_instagram_sessions():
        raise ValueError("Seçilen Instagram oturumu bulunamadı. Önce hesap oturumunu açın.")
    pacing = str(pacing_mode or "normal").strip().lower()
    if pacing not in PACING_PRESETS:
        raise ValueError("Geçerli bir indirme hızı seçin.")
    return profile, limit, login, pacing


class ArchiveDownloadWorker(ArchiveRescanCycle):
    def __init__(self, notify: Callable[[dict[str, object]], None]):
        self.notify = notify
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._login_thread: threading.Thread | None = None
        self._login_stop = threading.Event()
        self._manual_browser_pause = threading.Event()
        self._driver = None
        self._active_profile: Path | None = None
        self._latest_screenshot: bytes | None = None
        self._init_rescan_timer()
        self._state: dict[str, object] = {
            "status": "Hazır.",
            "running": False,
            "sourceProfile": "",
            "destination": "",
            "requested": 0,
            "scanned": 0,
            "downloaded": 0,
            "skipped": 0,
            "failed": 0,
            "current": "",
            "sessionAccount": "",
            "pacingMode": "normal",
            "pacingLabel": PACING_PRESETS["normal"]["label"],
            "waitRemaining": 0,
            "waitTotal": 0,
            "waitReason": "",
            "startedAt": None,
            "finishedAt": None,
            "browserOpen": False,
            "browserVisible": False,
            "browserHeadless": False,
            "loginRunning": False,
            "loginAccount": "",
            "loginReady": False,
            "loginStatus": "Arşiv Botu Instagram hesabı bekleniyor.",
            "hasScreenshot": False,
        }

    def snapshot(self) -> dict[str, object]:
        with self._lock:
            return {**self._state, **self._rescan_state()}

    def _update(self, **changes: object) -> None:
        with self._lock:
            self._state.update(changes)
            snapshot = self.snapshot()
        self.notify(snapshot)

    def _log(self, message: str) -> None:
        self._update(status=message)

    # ------------------------------------------------------------------ indirme

    def start(
        self, source_profile: str, count: int, session_account: str, destination: Path, pacing_mode: str = "normal"
    ) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                raise ValueError("Arşiv indirmesi zaten çalışıyor.")
            if self._login_thread and self._login_thread.is_alive():
                raise ValueError("Önce görünür giriş penceresindeki işlemi tamamlayın veya pencereyi kapatın.")
            destination = destination.resolve()
            if not destination.is_dir():
                raise ValueError("Seçilen hedef klasör bulunamadı.")
            if pacing_mode not in PACING_PRESETS:
                raise ValueError("Geçerli bir indirme hızı seçin.")
            pacing = PACING_PRESETS[pacing_mode]
            self._stop.clear()
            self._manual_browser_pause.clear()
            self._state.update(
                running=True,
                status="İndirme hazırlanıyor...",
                sourceProfile=source_profile,
                destination=str(destination),
                requested=count,
                scanned=0,
                downloaded=0,
                skipped=0,
                failed=0,
                current="",
                sessionAccount=session_account,
                hasScreenshot=False,
                pacingMode=pacing_mode,
                pacingLabel=pacing["label"],
                waitRemaining=0,
                waitTotal=0,
                waitReason="",
                startedAt=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                finishedAt=None,
            )
            self._latest_screenshot = None
            self._close_browser()
            self._thread = threading.Thread(
                target=self._run,
                args=(source_profile, count, session_account, destination, pacing_mode),
                daemon=True,
                name="instagram-archive-download",
            )
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._log("Durdurma istendi; devam eden indirme güvenli biçimde tamamlanıyor...")

    def toggle_browser_visibility(self) -> bool:
        """Show the running scan browser for manual scrolling, or hide and resume it."""
        with self._lock:
            if not self._state.get("running") or self._driver is None:
                raise ValueError("Çalışan bir arşiv indirmesi yok.")
            if self._state.get("browserHeadless"):
                raise ValueError("Arşiv headless modda çalışıyor; gösterilecek Chrome penceresi yok.")
            driver = self._driver
            visible = bool(self._state.get("browserVisible"))

        if visible:
            self._place_background_browser(driver)
            self._manual_browser_pause.clear()
            self._update(
                browserVisible=False,
                status="Chrome ekran dışına alındı; tarama kaldığı yerden devam ediyor.",
            )
            return False

        self._manual_browser_pause.set()
        self._place_visible_browser(driver)
        self._update(
            browserVisible=True,
            status=(
                "Chrome görünür ve tarama duraklatıldı; Reel listesini elle aşağı kaydırın. "
                "Bitince aynı düğmeye basıp devam edin."
            ),
        )
        return True

    # ------------------------------------------------------------------ login

    def start_login(self, username: object) -> None:
        account = safe_username(username)
        with self._lock:
            if self._state.get("running"):
                raise ValueError("İndirme çalışırken giriş penceresi açılamaz.")
            if self._login_thread and self._login_thread.is_alive():
                raise ValueError("Arşiv Botu için bir giriş penceresi zaten açık.")
            self._close_browser()
            self._login_stop.clear()
            self._latest_screenshot = None
            self._state.update(
                loginRunning=True,
                loginAccount=account,
                loginReady=False,
                loginStatus="Arşiv Botu'nun görünür Chrome penceresi açılıyor...",
                hasScreenshot=False,
            )
            self._login_thread = threading.Thread(
                target=self._run_login,
                args=(account,),
                daemon=True,
                name="archive-instagram-login",
            )
            self._login_thread.start()

    def stop_login(self) -> None:
        self._login_stop.set()
        self._close_browser()
        self._update(
            loginRunning=False,
            loginStatus="Arşiv Botu giriş penceresi kapatıldı.",
            hasScreenshot=False,
        )

    def _close_browser(self) -> None:
        self._manual_browser_pause.clear()
        driver = self._driver
        profile = self._active_profile
        self._driver = None
        self._active_profile = None
        if driver is not None:
            safe_quit_undetected(driver)
        if profile is not None:
            self._terminate_profile_chrome(profile)
        self._update(browserOpen=False, browserVisible=False, browserHeadless=False, hasScreenshot=False)

    @staticmethod
    def _terminate_profile_chrome(profile: Path) -> None:
        """Yalnız bu kalıcı profili kullanan yetim Chrome süreçlerini kapat."""
        if os.name != "nt":
            return
        script = (
            "$needle=$env:BOT_PROFILE_TERMINATE_TARGET; "
            "if ([string]::IsNullOrWhiteSpace($needle)) { exit 2 }; "
            "Get-CimInstance Win32_Process -Filter \"Name = 'chrome.exe'\" "
            "| Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0 } "
            "| ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
        )
        try:
            environment = os.environ.copy()
            environment["BOT_PROFILE_TERMINATE_TARGET"] = str(profile)
            subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=environment,
                timeout=15,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                check=False,
            )
            time.sleep(0.5)
        except (OSError, subprocess.SubprocessError):
            pass

    @staticmethod
    def _profile_options(profile: Path, *, headless: bool = False, download_mode: bool = False):
        def options_factory():
            options = uc.ChromeOptions()
            options.add_argument(f"--user-data-dir={profile}")
            options.add_argument("--profile-directory=Default")
            options.add_argument("--lang=tr-TR")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_argument("--mute-audio")
            if download_mode:
                # Tarama/indirme: gerçek headless mod ve sabit viewport.
                options.add_argument("--window-size=1366,768")
                if not headless:
                    options.add_argument("--window-position=-10000,-10000")
                # Headless taramada da lazy-load için zamanlayıcıları koru.
                options.add_argument("--disable-background-timer-throttling")
                options.add_argument("--disable-backgrounding-occluded-windows")
                options.add_argument("--disable-renderer-backgrounding")
                options.add_argument("--disable-features=CalculateNativeWinOcclusion")
                # Fingerprint azaltıcılar
                options.add_argument("--disable-automation")
                options.add_argument("--disable-infobars")
                options.add_argument("--disable-notifications")
                options.add_argument("--disable-popup-blocking")
                options.add_argument("--ignore-certificate-errors")
                options.add_argument("--allow-running-insecure-content")
            else:
                # Giriş modu: görünür, normal boyut
                options.add_argument("--window-size=1366,768")
            if headless:
                options.add_argument("--headless=new")
            # CDP ağ dinleme için performance log etkinleştir
            options.set_capability(
                "goog:loggingPrefs", {"performance": "ALL"}
            )
            return options
        return options_factory

    @staticmethod
    def _place_background_browser(driver) -> None:
        """Keep the headful scan window off-screen without minimizing it."""
        try:
            driver.set_window_rect(x=-10000, y=-10000, width=1366, height=768)
        except (AttributeError, WebDriverException):
            try:
                driver.set_window_position(-10000, -10000)
            except (AttributeError, WebDriverException):
                pass

    @staticmethod
    def _place_visible_browser(driver) -> None:
        """Move the running headful Chrome onto the desktop for manual recovery."""
        try:
            driver.set_window_rect(x=40, y=40, width=1366, height=768)
        except (AttributeError, WebDriverException):
            try:
                driver.set_window_position(40, 40)
            except (AttributeError, WebDriverException):
                pass
        try:
            driver.execute_script("window.focus();")
        except (AttributeError, WebDriverException):
            pass

    def _is_logged_in(self, driver) -> bool:
        try:
            current_url = (driver.current_url or "").lower()
            if any(part in current_url for part in ("/accounts/login", "/challenge", "/checkpoint")):
                return False
            WebDriverWait(driver, 3).until(
                EC.presence_of_element_located(
                    (By.CSS_SELECTOR, "svg[aria-label='Ana Sayfa'], svg[aria-label='Home'], nav")
                )
            )
            return True
        except (TimeoutException, WebDriverException):
            return False

    @staticmethod
    def _fill_login_username(driver, username: str) -> None:
        try:
            username_input = WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "input[name='username'], input[name='email'], input[autocomplete*='username']"))
            )
            driver.execute_script(
                """
                const element = arguments[0], value = arguments[1];
                const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                setter.call(element, value);
                element.dispatchEvent(new Event('input', {bubbles: true}));
                element.dispatchEvent(new Event('change', {bubbles: true}));
                """,
                username_input,
                username,
            )
            password_input = driver.find_element(By.CSS_SELECTOR, "input[name='password'], input[type='password']")
            password_input.click()
        except (TimeoutException, WebDriverException):
            return

    def _run_login(self, username: str) -> None:
        driver = None
        profile = account_root(username) / "chrome-profile"
        try:
            profile.mkdir(parents=True, exist_ok=True)
            self._terminate_profile_chrome(profile)
            self._active_profile = profile
            driver = start_undetected_chrome(
                uc,
                self._profile_options(profile, headless=False),
                log=lambda value: self._update(loginStatus=str(value)),
                use_subprocess=True,
                headless=False,
            )
            self._driver = driver
            self._update(browserOpen=True)
            driver.set_page_load_timeout(60)
            driver.get("https://www.instagram.com/")
            self._capture_screenshot()
            if not self._is_logged_in(driver):
                driver.get("https://www.instagram.com/accounts/login/")
                self._fill_login_username(driver, username)
                self._update(loginStatus="Şifrenizi görünür Chrome penceresinde yazıp Instagram girişini tamamlayın.")
            deadline = time.monotonic() + 300
            while not self._login_stop.is_set() and time.monotonic() < deadline:
                self._capture_screenshot()
                if self._is_logged_in(driver):
                    marker = account_root(username) / ".session_valid"
                    marker.parent.mkdir(parents=True, exist_ok=True)
                    marker.write_text("valid\n", encoding="utf-8")
                    self._update(
                        loginRunning=False,
                        loginReady=True,
                        loginStatus="Arşiv Botu girişi doğrulandı; ayrı profil kaydedildi.",
                    )
                    return
                if not getattr(driver, "window_handles", []):
                    raise RuntimeError("Chrome penceresi kapatıldı.")
                self._login_stop.wait(2)
            if self._login_stop.is_set():
                self._update(loginStatus="Giriş penceresi kapatıldı.")
            else:
                self._update(loginStatus="Giriş için 5 dakikalık süre doldu.")
        except Exception as error:
            self._update(loginStatus=f"Arşiv Botu Instagram girişi açılamadı: {explain_chrome_start_error(error)}")
            self._close_browser()
        finally:
            self._update(loginRunning=False)

    def screenshot_bytes(self) -> bytes | None:
        with self._lock:
            return self._latest_screenshot

    def _capture_screenshot(self) -> None:
        driver = self._driver
        if driver is None:
            return
        try:
            image = driver.get_screenshot_as_png()
        except Exception:
            return
        if image:
            with self._lock:
                self._latest_screenshot = image
            self._update(hasScreenshot=True)

    # ------------------------------------------------------------------ yardımcılar

    @staticmethod
    def _existing_ids(destination: Path) -> set[str]:
        """Hedef klasördeki mevcut MP4 dosyalarının ID setini döndürür."""
        found = set()
        for path in destination.glob("*.mp4"):
            match = VIDEO_PATTERN.fullmatch(path.name)
            if match and path.is_file() and _validate_mp4(path):
                found.add(match.group("id"))
        return found

    def _start_browser(self, session_account: str):
        profile = account_root(session_account) / "chrome-profile"
        if not profile.is_dir():
            raise RuntimeError("Kayıtlı Instagram tarayıcı profili bulunamadı.")
        self._terminate_profile_chrome(profile)
        self._active_profile = profile
        driver = None
        try:
            driver = start_undetected_chrome(
                uc,
                self._profile_options(profile, headless=True, download_mode=True),
                log=self._log,
                use_subprocess=True,
                headless=True,
            )
            driver.set_page_load_timeout(60)
            driver.get("https://www.instagram.com/")
            if not self._is_logged_in(driver):
                raise RuntimeError(
                    "Instagram oturumu geçerli değil. Girişi aç / yenile düğmesiyle hesabı yeniden bağlayın."
                )
            return driver
        except Exception as error:
            safe_quit_undetected(driver)
            message = str(error)
            if "oturumu geçerli değil" in message:
                raise
            raise RuntimeError(
                "Instagram tarayıcısı açılamadı. Aynı hesap başka botta açıksa onu durdurup tekrar deneyin. "
                + explain_chrome_start_error(error)
            ) from error

    def _wait_with_countdown(self, seconds: int, reason: str) -> None:
        total = max(1, int(seconds))
        for remaining in range(total, 0, -1):
            while self._manual_browser_pause.is_set():
                if self._stop.wait(0.25):
                    raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
            if self._rescan_due():
                if self._stop.is_set():
                    raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
                break
            self._update(
                status=f"{reason} Sonraki indirmeye {remaining} saniye.",
                waitRemaining=remaining,
                waitTotal=total,
                waitReason=reason,
            )
            if self._stop.wait(1):
                raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
        self._update(waitRemaining=0, waitTotal=0, waitReason="")

    # ------------------------------------------------------------------ ana döngü

    def _run(
        self, source_profile: str, count: int, session_account: str, destination: Path, pacing_mode: str
    ) -> None:
        history_root = destination / ARCHIVE_HISTORY_DIR

        def source_log(message: str) -> None:
            visible = re.sub(
                r"(\d+)/\d+( yeni Reel bulundu)",
                lambda m: f"{m.group(1)}/{count}{m.group(2)}",
                str(message),
            )
            self._log(visible)

        source = InstagramSourceCopy(history_root, self._stop, source_log)
        # The UI can pause the source collector while the user manually scrolls
        # the same Chrome tab to recover from a lazy-load stall.
        source.manual_pause = self._manual_browser_pause
        source.scan_cycle_expired = self._rescan_due
        pacing = PACING_PRESETS[pacing_mode]
        downloaded = skipped = failed = 0
        attempted: set[str] = set()
        candidate_count = 0
        processed = 0
        driver = None
        scan_stalled = False

        # İndirme için source.transfer() kullanılacak config — caption/paylaşım yok
        config = {
            "sourceMode": "instagram",
            "sourceProfile": source_profile,
            "sourceLinks": "",
            "sourceLimit": 1,
            "sourceOrder": "listed",
            "captionMode": "empty",
            "forbiddenWords": "",
        }

        try:
            self._begin_rescan_cycle(first=True)
            ffmpeg = find_ffmpeg(APP_ROOT)
            source.transfer_options = {
                "ffmpeg_location": ffmpeg,
                "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best",
                "merge_output_format": "mp4",
                "fixup": "detect_or_warn",
                "skip_unavailable_fragments": False,
            }
            self._log(f"Instagram oturumu hazırlanıyor: @{session_account}")
            driver = self._start_browser(session_account)
            self._driver = driver
            self._update(browserOpen=True, browserVisible=False, browserHeadless=True)
            self._capture_screenshot()

            # Mevcut MP4'ler + geçmiş kayıtlar → tekrar indirilmeyecekler
            existing = self._existing_ids(destination)
            history = source.history()
            # Missing/unplayable archive files must be downloadable again.
            excluded = existing | set(history["pending"])

            while downloaded < count:
                if self._stop.is_set():
                    raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
                if self._rescan_due():
                    excluded = self._renew_rescan(source, destination, attempted, count - downloaded)

                remaining = count - downloaded
                reserve = min(100, max(10, remaining // 10))
                scan_limit = remaining + reserve
                self._log(
                    f"@{source_profile} Reels profili taranıyor; "
                    f"hedefe kalan {remaining} yeni MP4..."
                )

                items = source._collect_profile(
                    driver,
                    source_profile,
                    scan_limit,
                    excluded | attempted,
                )
                scan_stalled = bool(getattr(source, "last_scan_stalled", False))
                if self._rescan_due():
                    excluded = self._renew_rescan(source, destination, attempted, count - downloaded)
                    continue
                self._capture_screenshot()
                candidate_count += len(items)
                # Grid/CDP resources are not Reel-identity bound. Download only
                # the individual Reel URL through the extractor or its own page.
                self._update(
                    scanned=candidate_count,
                    status=(
                        f"{len(items)} yeni aday bulundu; "
                        f"hedef {count}, indirilen {downloaded}."
                    ),
                )

                if not items:
                    self._wait_for_rescan(count - downloaded)
                    excluded = self._renew_rescan(source, destination, attempted, count - downloaded)
                    continue

                for item in items:
                    if self._stop.is_set():
                        raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
                    if self._rescan_due():
                        break

                    reel_id = str(item["id"])
                    attempted.add(reel_id)
                    target = destination / f"{reel_id}.mp4"

                    if target.is_file() and _validate_mp4(target):
                        skipped += 1
                        self._update(skipped=skipped)
                        continue

                    self._update(
                        current=reel_id,
                        status=f"Hedef {count} · {downloaded + 1}. MP4 indiriliyor: {reel_id}",
                    )
                    self._capture_screenshot()

                    try:
                        transferred = False

                        # Birincil yöntem: Reel kimliğine bağlı yt-dlp indirmesi.
                        last_error: SourceUnavailable | None = None
                        if not transferred:
                            for attempt in range(2):
                                try:
                                    with source.transfer(driver, item, config) as (tmp_path, _caption):
                                        tmp_size = 0
                                        try:
                                            tmp_size = Path(tmp_path).stat().st_size
                                        except OSError:
                                            pass
                                        if tmp_size <= 0:
                                            raise SourceUnavailable(
                                                f"{reel_id}: indirilen dosya boş döndü."
                                            )
                                        partial = destination / f".{reel_id}.mp4.part"
                                        try:
                                            shutil.copy2(tmp_path, partial)
                                            self._update(status=f"{reel_id}: ses ve görüntü hazırlanıyor...")
                                            prepare_mp4(partial, self._stop, executable=ffmpeg,
                                                        require_audio=item.get("has_audio") is not False)
                                            commit_mp4(partial, target)
                                        finally:
                                            partial.unlink(missing_ok=True)
                                    transferred = True
                                    break
                                except SourceUnavailable as err:
                                    last_error = err
                                    if attempt:
                                        break
                                    self._wait_with_countdown(8, f"{reel_id} için geçici hata; yeniden deneniyor.")

                        # Yedek yöntem: aynı Reel sayfasından browser indirmesi.
                        if not transferred:
                            self._update(
                                status=f"{reel_id}: yt-dlp başarısız; browser fallback deneniyor...",
                            )
                            partial = destination / f".{reel_id}.mp4.part"
                            try:
                                download_reel_via_browser(
                                    driver,
                                    item,
                                    partial,
                                    self._stop,
                                    log_fn=self._log,
                                )
                                # Browser fallback already assembles and fully
                                # decodes each candidate before returning.
                                commit_mp4(partial, target)
                                transferred = True
                            except SourceCancelled:
                                partial.unlink(missing_ok=True)
                                raise
                            except Exception as fb_err:
                                partial.unlink(missing_ok=True)
                                if last_error is None:
                                    last_error = SourceUnavailable(str(fb_err))

                        if not transferred and last_error is not None:
                            raise last_error

                        # Tekrar indirilmesin diye geçmişe kaydet
                        source.mark_published(item)
                        existing.add(reel_id)
                        downloaded += 1
                        self._update(downloaded=downloaded, current="")
                        self._capture_screenshot()

                    except SourceCancelled:
                        raise
                    except SourceUnavailable as error:
                        failed += 1
                        self._update(
                            failed=failed,
                            current="",
                            status=f"{error} Yerine başka Reel aranacak.",
                        )
                    except SourceCopyError as error:
                        raise RuntimeError(str(error)) from error
                    except OSError as error:
                        raise RuntimeError(f"Seçilen klasöre video yazılamadı: {error}") from error

                    processed += 1
                    if downloaded >= count:
                        break
                    if not self._stop.is_set():
                        batch_size = int(pacing["batch"])
                        if processed % batch_size == 0:
                            low, high = pacing["break"]
                            self._wait_with_countdown(
                                random.randint(int(low), int(high)),
                                f"{batch_size} video işlendi; Instagram'ı dinlendiriyorum.",
                            )
                        else:
                            low, high = pacing["delay"]
                            self._wait_with_countdown(
                                random.randint(int(low), int(high)),
                                f"{pacing['label']} hız beklemesi.",
                            )

                if downloaded < count and self._rescan_due():
                    excluded = self._renew_rescan(source, destination, attempted, count - downloaded)
                    continue
                if downloaded < count and (scan_stalled or len(items) < scan_limit):
                    self._wait_for_rescan(count - downloaded)
                    excluded = self._renew_rescan(source, destination, attempted, count - downloaded)

            # Sonuç mesajı
            if downloaded >= count:
                final_status = f"Tamamlandı: hedeflenen {count} yeni MP4 indirildi."
            elif self._stop.is_set():
                final_status = f"İndirme durduruldu. {downloaded} video klasörde kaldı."
            else:
                final_status = f"İşlem sona erdi: {downloaded}/{count} MP4 indirildi."
            self._update(status=final_status)

        except SourceCancelled:
            self._update(status=f"İndirme durduruldu. {downloaded} video klasörde kaldı.")
        except (SourceCopyError, RuntimeError, ValueError) as error:
            self._update(status=str(error), error=str(error))
        except Exception as error:
            self._update(status=f"Beklenmeyen hata: {error}", error=str(error))
        finally:
            self._end_rescan_timer()
            self._manual_browser_pause.clear()
            self._driver = None
            if driver is not None:
                safe_quit_undetected(driver)
            if self._active_profile is not None:
                self._terminate_profile_chrome(self._active_profile)
                self._active_profile = None
            self._update(
                running=False,
                browserOpen=False,
                browserVisible=False,
                browserHeadless=False,
                hasScreenshot=False,
                current="",
                waitRemaining=0,
                waitTotal=0,
                waitReason="",
                finishedAt=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            )
