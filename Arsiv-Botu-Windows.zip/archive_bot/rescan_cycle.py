"""Six-hour page cycles, independent from individual media URL lifetimes."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import math
import time

from source_copy import SourceCancelled

RESCAN_INTERVAL_SECONDS = 6 * 60 * 60


class ArchiveRescanCycle:
    def _init_rescan_timer(self) -> None:
        self._rescan_deadline = None
        self._next_rescan_at = None
        self._scan_cycle = 0

    def _rescan_state(self) -> dict:
        remaining = 0 if self._rescan_deadline is None else max(
            0, math.ceil(self._rescan_deadline - time.monotonic()))
        return {"rescanIntervalSeconds": RESCAN_INTERVAL_SECONDS,
                "rescanRemaining": remaining, "nextRescanAt": self._next_rescan_at,
                "scanCycle": self._scan_cycle}

    def _begin_rescan_cycle(self, *, first: bool = False) -> None:
        with self._lock:
            self._scan_cycle = 1 if first else self._scan_cycle + 1
            self._rescan_deadline = time.monotonic() + RESCAN_INTERVAL_SECONDS
            self._next_rescan_at = (datetime.now(timezone.utc) + timedelta(
                seconds=RESCAN_INTERVAL_SECONDS)).isoformat(timespec="seconds")
        self._update()

    def _rescan_due(self) -> bool:
        return self._rescan_deadline is not None and time.monotonic() >= self._rescan_deadline

    def _wait_for_rescan(self, remaining: int) -> None:
        self._update(current="", waitRemaining=0, waitTotal=0, waitReason="",
                     status=f"Bu turdaki adaylar işlendi; hedefe {remaining} MP4 kaldı. "
                            "6 saatlik sayaç dolunca sayfa yeniden taranacak.")
        # No network requests or sleeps that block Stop while waiting for a cycle.
        while not self._rescan_due() or self._manual_browser_pause.is_set():
            if self._stop.wait(0.5):
                raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
        if self._stop.is_set():
            raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")

    def _renew_rescan(self, source, destination, attempted: set, remaining: int) -> set:
        while self._manual_browser_pause.is_set():
            if self._stop.wait(0.5):
                raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
        if self._stop.is_set():
            raise SourceCancelled("İndirme kullanıcı tarafından durduruldu.")
        source.refresh()
        # Published history alone must not hide a missing/incomplete file.
        excluded = self._existing_ids(destination) | set(source.history()["pending"])
        attempted.clear()
        self._begin_rescan_cycle()
        self._update(current="", waitRemaining=0, waitTotal=0, waitReason="",
                     status=f"6 saatlik tur tamamlandı; {self._scan_cycle}. tarama başlıyor. "
                            f"İndirilenler korunuyor, hedefe {remaining} MP4 kaldı.")
        return excluded

    def _end_rescan_timer(self) -> None:
        with self._lock:
            self._rescan_deadline = None
            self._next_rescan_at = None
