# Arşiv Botu — Windows

Instagram profillerindeki Reels videolarını seçtiğiniz klasöre MP4 olarak indiren yerel Windows uygulamasıdır.

## Gereksinimler

- Windows 10 veya Windows 11
- Google Chrome
- Python 3

## Kurulum

1. ZIP dosyasını bir klasöre çıkarın.
2. `Kurulum.bat` dosyasını çalıştırın.
3. Kurulum tamamlandıktan sonra `Baslat.bat` dosyasını açın.
4. Panel otomatik olarak `http://127.0.0.1:5090` adresinde açılır.

## Özellikler

- Birden fazla Instagram hesabı için ayrı çalışma alanı
- Görünür girişten sonra arka planda Chrome kullanımı
- Reel kimliğine göre tekrar indirmeyi önleme
- MP4 görüntü ve ses doğrulaması
- Hızlı, normal ve güvenli indirme temposu
- İndirme klasörünü panelden seçebilme

## Gizlilik

Hesap oturumları ve indirilen videolar yalnızca kullanıcının bilgisayarında saklanır. Bu ZIP dosyasında hesap, çerez, video veya kişisel veri bulunmaz.

> Bu araç yalnızca erişim ve indirme yetkiniz bulunan içerikler için kullanılmalıdır.
